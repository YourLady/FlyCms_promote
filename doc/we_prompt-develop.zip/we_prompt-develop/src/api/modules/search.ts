import { PORT1 } from "@/api/config/servicePort";
import http from "@/api";

/****
 * 例子
 * export const getMyContentList = (params: string) => {
  return http.get(PORT1 + `/query/publishContentList?userId=${params}`, { loading: true }); // 正常 post json 请求  ==>  application/json
  // return http.post<Login.ResLogin>(PORT1 + `/login`, params, { loading: false }); // 控制当前请求不显示 loading
  // return http.post<Login.ResLogin>(PORT1 + `/login`, {}, { params }); // post 请求携带 query 参数  ==>  ?username=admin&password=123456
  // return http.post<Login.ResLogin>(PORT1 + `/login`, qs.stringify(params)); // post 请求携带表单参数  ==>  application/x-www-form-urlencoded
  // return http.get<Login.ResLogin>(PORT1 + `/login?${qs.stringify(params, { arrayFormat: "repeat" })}`); // get 请求可以携带数组等复杂参数
};
 */

/**
 * @name 全局搜索
 */
// 搜索
export const searchContentList = (userId: string | number, keyword: string, type: string | number) => {
  return http.get(PORT1 + `/search?userId=${userId}&keyword=${keyword}&type=${type}`, {}, { loading: false });
};
