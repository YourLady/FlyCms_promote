import { PORT1 } from "@/api/config/servicePort";
import http from "@/api";
import { Home } from "@/api/interface/index";
/****
 * 例子
 * export const getMyContentList = (params: string) => {
  return http.get(PORT1 + `/query/publishContentList?userId=${params}`, { loading: true }); // 正常 post json 请求  ==>  application/json
  // return http.post<Login.ResLogin>(PORT1 + `/login`, params, { loading: false }); // 控制当前请求不显示 loading
  // return http.post<Login.ResLogin>(PORT1 + `/login`, {}, { params }); // post 请求携带 query 参数  ==>  ?username=admin&password=123456
  // return http.post<Login.ResLogin>(PORT1 + `/login`, qs.stringify(params)); // post 请求携带表单参数  ==>  application/x-www-form-urlencoded
  // return http.get<Login.ResLogin>(PORT1 + `/login?${qs.stringify(params, { arrayFormat: "repeat" })}`); // get 请求可以携带数组等复杂参数
};
 */
/**
 * @name prompt圈子
 */
// 查询我发布的列表
export const getMyContentList = (params: string | number) => {
  return http.get(PORT1 + `/query/publishContentList?userId=${params}`, {}, { loading: false });
};

// 查询关注人内容的列表
export const getFollowContentList = (params: string | number) => {
  return http.get(PORT1 + `/query/followPublishContent?userId=${params}`, {}, { loading: false });
};

// 查询关注人列表
export const getFollowUsersList = (params: string | number) => {
  return http.get(`/query/followUsers?userId=${params}`, {}, { loading: false });
};

// 取消关注
export const setCancelFollowUsers = (params: Home.CancelStatus) => {
  return http.post(PORT1 + `/cancel/follow?userId=${params.userId}&followUserId=${params.followUserId}`, params, {
    loading: true
  });
};

// 查询逛逛列表
export const getRecommendList = (params: string | number) => {
  return http.get(PORT1 + `/query/recommendPublishContent?userId=${params}`, {}, { loading: false });
};

// 点赞
export const setLike = (params: Home.LikeStatus) => {
  return http.post(PORT1 + `/like?userId=${params.userId}&publishContentId=${params.publishContentId}`, { loading: true });
};

// 取消点赞
export const setUnLike = (params: Home.LikeStatus) => {
  return http.post(PORT1 + `/cancelLike?userId=${params.userId}&publishContentId=${params.publishContentId}`, { loading: true });
};

// 收藏
export const setCollect = (params: Home.LikeStatus) => {
  return http.post(PORT1 + `/collect?userId=${params.userId}&publishContentId=${params.publishContentId}`, { loading: true });
};

// 取消收藏
export const setCancelCollect = (params: Home.LikeStatus) => {
  return http.post(PORT1 + `/cancelCollect?userId=${params.userId}&publishContentId=${params.publishContentId}`, {
    loading: true
  });
};

// 添加关注
export const setFollow = (params: Home.CancelStatus) => {
  return http.post(`/save/follow?userId=${params.userId}&followUserId=${params.followUserId}`, { loading: true });
};

// 取消关注
export const setCancelFollow = (params: Home.CancelStatus) => {
  return http.post(`/cancel/follow?userId=${params.userId}&followUserId=${params.followUserId}`, { loading: true });
};

// 添加评论?userId=${params.userId}&contentId=${params.contentId}&commentContent=${params.commentContent}&userName=${userName}
export const addCommentByUser = (params: Home.Comment) => {
  return http.post(PORT1 + `/addComment`, params, { loading: true });
};
