import { User } from "@/api/interface/index";
import { PORT1 } from "@/api/config/servicePort";
import http from "@/api";

/**
 * @name 用户管理模块
 */
// export const getUserList = (params: User.ReqUserParams) => {
//   return http.post<ResPage<User.ResUserList>>(PORT1 + `/user/list`, params);
// };

// 获取用户性别字典
export const getUserGender = () => {
  return http.get<User.ResGender[]>(PORT1 + `/user/gender`);
};

// 获取用户个人信息
export const getUserInfo = () => {
  return http.post<User.ResRole[]>(PORT1 + `/ucenter/account/`);
};

// 更新个人信息 /ucenter/account_update?user
export const updateUserInfo = (params: any) => {
  return http.post<User.ResRole[]>(PORT1 + `/ucenter/account_update`, params);
};
