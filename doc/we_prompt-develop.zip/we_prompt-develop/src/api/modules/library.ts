import { PORT1 } from "@/api/config/servicePort";
import http from "@/api";

/****
 * 例子
 * export const getMyContentList = (params: string) => {
  return http.get(PORT1 + `/query/publishContentList?userId=${params}`, { loading: true }); // 正常 post json 请求  ==>  application/json
  // return http.post<Login.ResLogin>(PORT1 + `/login`, params, { loading: false }); // 控制当前请求不显示 loading
  // return http.post<Login.ResLogin>(PORT1 + `/login`, {}, { params }); // post 请求携带 query 参数  ==>  ?username=admin&password=123456
  // return http.post<Login.ResLogin>(PORT1 + `/login`, qs.stringify(params)); // post 请求携带表单参数  ==>  application/x-www-form-urlencoded
  // return http.get<Login.ResLogin>(PORT1 + `/login?${qs.stringify(params, { arrayFormat: "repeat" })}`); // get 请求可以携带数组等复杂参数
};
 */
/**
 * @name prompt库
 */
interface Save {
  userId: string;
  title: string;
  picture: string;
  description: string;
  publicflag: string | number;
  id: string | number;
}
// 保存创建新作品
export const saveArticleApi = (params: Save) => {
  return http.post(PORT1 + `/promote/addPromoteSave`, params, { loading: false });
};
// 当前登录账号所有作品列表 /people/{shortUrl}/0/promotesList
export const getAllArticleList = (shortUrl: any) => {
  return http.post(
    `/people/${shortUrl}/2/promotesList`,
    {},
    { loading: false }
    // { loading: false, headers: { "Content-Type": "application/json;charset=UTF-8" } }
  );
};
// 当前登录账号公开作品列表/people/{shortUrl}/1/promotes
export const getPromotesArticleList = (params: any) => {
  return http.post(`/people/${params}/1/promotesList`, {}, { loading: false });
};
// 当前登录账号不公开作品列表 /people/{shortUrl}/0/promotes
export const getNoPromotesList = (params: any) => {
  return http.post(`/people/${params}/0/promotesList`, {}, { loading: false });
};
// 删除作品 /user/delete/publishContent?id=3
export const deletePublishContent = (id: any) => {
  // return http.post(PORT1 + `/delete/publishContent?id=${id}`, {}, { loading: false });
  return http.post(PORT1 + `promote/delete?id=${id}`, {}, { loading: false });
};

// 删除提示词
export const deleteArticle = (id: any) => {
  return http.post(PORT1 + `/article/delete?id=${id}`, {}, { loading: false });
};

// 当前登录账号收藏列表
export const getCollectPublishContent = (userId: any) => {
  return http.get(PORT1 + `/query/collectPublishContent?userId=${userId}`, {}, { loading: false });
  // return http.get(PORT1 + `/query/collectPromote?userId=${userId}&promoteid=${promoteid}`, {}, { loading: false });
};

// 获取作品详情
export const findArticleById = (userId: any) => {
  return http.post(`/findPromoteArticleById/${userId}`, {}, { loading: false });
};
// 获取作品下面的提示词list
export const findPromoteArticleListById = (promoteid: any) => {
  return http.post(`/findPromoteArticleListById/${promoteid}`, {}, { loading: false });
};

// 创建提示词
export const addSaveArticle = (params: any) => {
  return http.post(PORT1 + `/promote/addArticle`, params, { loading: false });
};
