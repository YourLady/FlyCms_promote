import { defineStore } from "pinia";
import { HomeState } from "@/stores/interface";
import piniaPersistConfig from "@/stores/helper/persist";

export const useHomeStore = defineStore({
  id: "home",
  state: (): HomeState => ({
    theme: "vs"
  }),
  getters: {},
  actions: {
    // Set Token
    setTheme(theme: string) {
      this.theme = theme;
    }
  },
  persist: piniaPersistConfig("home")
});
