import { defineStore } from "pinia";
import { UserState } from "@/stores/interface";
import piniaPersistConfig from "@/stores/helper/persist";

export const useUserStore = defineStore({
  id: "geeker-user",
  state: (): UserState => ({
    token: "",
    userInfo: {
      access_token: "",
      userId: "",
      userMobile: "",
      userName: "",
      sessionKey: "",
      sex: 0,
      shortUrl: "",
      signature: "",
      status: 0,
      loginIp: "",
      nickName: "",
      password: "",
      avatar: "",
      balance: null,
      description: ""
    },
    userStatus: false,
    wxStatus: false
  }),
  getters: {},
  actions: {
    // Set Token
    setToken(token: string) {
      this.token = token;
    },
    // Set setUserInfo
    setUserInfo(userInfo: UserState["userInfo"]) {
      this.userInfo = { ...userInfo };
    },
    changeStatus(userStatus: boolean) {
      this.userStatus = userStatus;
    },
    changeWxStatus(wxStatus: boolean) {
      this.wxStatus = wxStatus;
    }
  },
  persist: piniaPersistConfig("geeker-user")
});
