<template>
  <el-card class="box-card">
    <div v-for="(item, index) in data" :key="index" class="text item" @click="popoverFn(item)">
      <el-icon>
        <component :is="item.icon"></component>
      </el-icon>
      <span>{{ item.title }}</span>
    </div>
  </el-card>
</template>
<script setup lang="ts" name="PopoverAdd">
import { ref, watch } from "vue";
import { useRouter } from "vue-router";
import { deletePublishContent, deleteArticle } from "@/api/modules/library";
import mittBus from "@/utils/mittBus";

const router = useRouter();

// 接收父组件参数并设置默认值
interface Popover {
  icon: string;
  title: string;
  fun: string;
}

const props = defineProps<{
  data?: Popover[];
  rowData: any;
}>();

const popoverData = ref<{ [key: string]: any }[]>([]);
const popoverAllData = ref<{ [key: string]: any }[]>([]);

const popoverFn = (item: any) => {
  console.log("popoverFn", item);
  if (item.title == "创建新提示词") {
    console.log("rowData", props.rowData);
    router.push({
      path: `/assembly/tabs/detail`,
      query: {
        row: JSON.stringify(props.rowData),
        type: "edit"
      }
    });
  }
  if (item.title == "删除") {
    // 删除作品
    if (props.rowData.id == "0") {
      deleteFn(props.rowData.id);
    } else {
      // 删除提示词
      deleteArticleFn(props.rowData.id);
    }
  }
  if (item.title == "编辑封面") {
    console.log("item", item);
    console.log("rowData", props.rowData);
    mittBus.emit("openModalFn", {
      row: {
        remark: null,
        worksName: "",
        avatar: null,
        zhValue: "1"
      },
      options: {
        title: "创建新作品",
        refreshList: updateParentNode
      }
    });
  }

  if (item.title == "设为私密") {
    mittBus.emit("openModalFn", {
      row: {
        remark: null,
        worksName: "",
        avatar: null,
        zhValue: "1"
      },
      options: {
        title: "创建新作品",
        refreshList: updateParentNode
      }
    });
  }
};

const updateParentNode = () => {
  console.log("updateParentNode");
};

// 删除作品
const deleteFn = (id: any) => {
  deletePublishContent(id).then((res: any) => {
    console.log(res);
  });
};
// 删除提示词
const deleteArticleFn = (id: any) => {
  deleteArticle(id).then((res: any) => {
    console.log(res);
  });
};

watch(
  () => props.data,
  () => {
    if (props.data?.length) {
      popoverData.value = props.data;
      popoverAllData.value = [...props.data];
    }
  },
  { deep: true, immediate: true }
);

// emit
// const emit = defineEmits<{
//   change: [value: any];
// }>();
// const createNewPage: Function = inject("createNew") as Function;
// 暴露给父组件使用
defineExpose({ popoverData, popoverAllData });
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
<style lang="scss">
.box-card {
  .el-card__body {
    padding: 0 !important;
  }
}
</style>
