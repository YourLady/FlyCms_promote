<template>
  <el-card class="box-card">
    <div class="avatar" @click="toPersonage(cardObj)">
      <img :src="cardObj.avatar" alt="avatar" />
    </div>
    <div class="text item">
      <div class="item-head">
        <span class="head-name" @click="toPersonage(cardObj)">{{ cardObj.createBy }}</span>
        <div v-if="isShowFollow">
          <el-button v-if="cardObj.followStat === 0" class="ml-1 follw" size="small" @click="setFollowFn(cardObj)">
            <i :class="'iconfont icon-jiaguanzhuren'" style="margin-right: 6px"></i>
            关注
          </el-button>
          <el-button
            v-if="cardObj.followStat === 1"
            color="#626aef"
            class="ml-1 follw"
            size="small"
            @click="setFollowFn(cardObj)"
          >
            <i :class="'iconfont icon-yiguanzhuren'" style="margin-right: 6px"></i>
            已关注
          </el-button>
        </div>
      </div>
      <div class="time">
        <span>{{ cardObj.createTime }}</span>
      </div>
      <div>{{ cardObj.title }}</div>
      <div class="container">
        <!-- {{ cardObj.content }} -->
        <!-- <TextOverflow :text="cardObj.content" :max-lines="4">
          <template #default="{ clickToggle, expanded }">
            <button @click="clickToggle" class="btn">{{ expanded ? "收起" : "展开" }}</button>
          </template>
        </TextOverflow> -->
        <pre><code>{{ cardObj.content }}</code></pre>
      </div>
      <div class="main-operate">
        <div class="todo-list" @click="setLikeFn(cardObj)">
          <SvgIcon
            :name="'goods'"
            :icon-style="{ width: '16px', height: '16px', verticalAlign: 'bottom' }"
            v-if="cardObj.likeStat == 1"
          />
          <SvgIcon :name="'goods-asset'" :icon-style="{ width: '16px', height: '16px', verticalAlign: 'bottom' }" v-else />
          <!-- <i v-else :class="'iconfont icon-good'" :style="{ color: yanse }"></i> -->
          <span class="todo-list-text">{{ cardObj.likeCount }}</span>
        </div>
        <div class="todo-list" @click="collectFn(cardObj)">
          <i
            :class="'iconfont icon-icon_love'"
            :style="{ color: cardObj.collectStat == 1 ? 'red' : 'initial', fontSize: '14px' }"
          ></i>
          <span class="todo-list-text">{{ cardObj.collectCount }}</span>
        </div>
        <div class="todo-list" @click="openDrawer">
          <i :class="'iconfont icon-pinglun'" :style="{ fontSize: '18px' }"></i>
          <span class="todo-list-text">{{ cardObj.commentList.length }}</span>
        </div>
      </div>
    </div>
  </el-card>
</template>
<script setup lang="ts" name="PopoverAdd">
// import { ref } from "vue";
// import { User } from "@element-plus/icons-vue";
import { useRouter } from "vue-router";
import { setLike, setUnLike, setCollect, setCancelCollect, setFollow, setCancelFollow } from "@/api/modules/home";
// import TextOverflow from "@/components/TextOverflow/TextOverflow.vue";
import { ElMessage } from "element-plus";
import { useUserStore } from "@/stores/modules/user";
import SvgIcon from "@/components/SvgIcon/index.vue";
// userStore.userInfo.name
const userStore = useUserStore();
// const route = useRoute();
const router = useRouter();
import mittBus from "@/utils/mittBus";
const openDrawer = () => {
  mittBus.emit("openReviewDrawer", props.cardObj);
};
// 接收父组件参数并设置默认值
interface IRowsItem {
  [propName: string]: string | number;
}
interface CardObjProps {
  collectCount: number;
  commentCount: number;
  commentList: Array<IRowsItem>;
  content: string;
  createBy: string;
  createTime: string;
  id: number;
  isPublic: number;
  likeCount: number;
  promptId: string;
  publishTime: string;
  title: string;
  updateBy: string;
  updateTime: string;
  userId: string;
  avatar: string;
  followStat: number;
  collectStat: number;
  likeStat: number;
}
interface CardProps {
  cardObj: CardObjProps;
  getList: () => void;
  isShowFollow: boolean;
}

const props = defineProps<CardProps>();
const setFollowFn = (cardObj: CardObjProps) => {
  console.log("popoverFn", props.cardObj);
  if (cardObj.followStat === 0) {
    setFollow({ userId: userStore.userInfo.userId, followUserId: cardObj.userId }).then((res: any) => {
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  } else {
    setCancelFollow({ userId: userStore.userInfo.userId, followUserId: cardObj.userId }).then((res: any) => {
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  }
};
const setLikeFn = (item: any) => {
  if (item.likeStat != 1) {
    setLike({ userId: userStore.userInfo.userId, publishContentId: item.id }).then((res: any) => {
      console.log("点赞", res);
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  } else {
    setUnLike({ userId: userStore.userInfo.userId, publishContentId: item.id }).then((res: any) => {
      console.log("取消点赞", res);
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  }
};
const collectFn = (item: any) => {
  console.log("collectFn");
  if (item.collectStat != 1) {
    setCollect({ userId: userStore.userInfo.userId, publishContentId: item.id }).then((res: any) => {
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  } else {
    setCancelCollect({ userId: userStore.userInfo.userId, publishContentId: item.id }).then((res: any) => {
      if (res.code == 0) {
        ElMessage.success(res.message);
        props.getList();
      }
    });
  }
};

// 暴露给父组件使用
// defineExpose({ popoverData, popoverAllData });
const toPersonage = (row: any) => {
  console.log(row);
  let obj = JSON.stringify(row);
  router.push({ path: `/assembly/library/personage`, query: { row: obj } });
  // 路由传参接收
  // const route = useRoute();
  // console.log(route.query.id);
};
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
