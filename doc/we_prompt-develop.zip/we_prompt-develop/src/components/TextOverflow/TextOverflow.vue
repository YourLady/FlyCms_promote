<template>
  <div ref="textOverflow" class="text-overflow" :style="boxStyle">
    <div>
      <span ref="overEllipsis" class="color-3c fs24">
        <!--        {{ realText }}-->
        <span v-html="realText"></span>
      </span>
    </div>
    <div class="flex-box" ref="slotRef" v-if="showSlotNode">
      <div class="slot-box">
        <slot :click-toggle="toggle" :expanded="expanded"></slot>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onMounted, ref } from "vue";

//vue3实现多行文本展开收起组件
// const props = defineProps({
//   text: {
//     type: String,
//     default: ""
//   },
//   maxLines: {
//     type: Number,
//     default: 4
//     // slot 图标占据一行，实际为3行
//     // default: 3,
//   },
//   width: {
//     type: Number,
//     default: 309
//   }
// });
interface ChildPropsType {
  text: string | undefined;
  maxLines: number;
  width: number | string;
  // onClick: () => void;
}

const props = withDefaults(defineProps<ChildPropsType>(), {
  text: "",
  maxLines: 4,
  width: 309
});

let offset = ref(props.text.length);
let expanded = ref(false);
let slotBoxWidth = ref(0);
let textBoxWidth = ref(props.width);
let showSlotNode = ref(false);

const boxStyle = computed(() => {
  if (props.width) {
    return {
      width: props.width + "px"
    };
  } else {
    return {
      width: "309px"
    };
  }
});

const realText = computed(() => {
  // 是否被截取
  const isCutOut = offset.value !== props.text.length;
  let realText = props.text;
  if (isCutOut && !expanded.value) {
    realText = props.text.slice(0, offset.value) + "...";
  }
  return realText;
});
const calculateOffset = (from: any, to: any) => {
  nextTick(() => {
    if (Math.abs(from - to) <= 1) return;
    if (isOverflow()) {
      to = offset.value;
    } else {
      from = offset.value;
    }
    offset.value = Math.floor((from + to) / 2);
    calculateOffset(from, to);
  });
};

const isOverflow = () => {
  const { len, lastWidth } = getLines();

  if (len < props.maxLines) {
    return false;
  }
  if (props.maxLines) {
    // 超出部分 行数 > 最大行数 或则  已经是最大行数但最后一行宽度 + 后面内容超出正常宽度
    const lastLineOver = !!(len === props.maxLines && lastWidth + slotBoxWidth.value > textBoxWidth.value);
    if (len > props.maxLines || lastLineOver) {
      return true;
    }
  }
  return false;
};

const getLines = () => {
  const clientRects = overEllipsis.value.getClientRects();
  return {
    len: clientRects.length,
    lastWidth: clientRects[clientRects.length - 1]?.width
  };
};

const toggle = () => {
  expanded.value = !expanded.value;
};
let slotRef = ref();
let textOverflow = ref();
let overEllipsis = ref();
onMounted(() => {
  const { len } = getLines();
  if (len > props.maxLines) {
    showSlotNode.value = true;
    nextTick(() => {
      slotBoxWidth.value = slotRef.value.clientWidth;
      textBoxWidth.value = textOverflow.value.clientWidth;
      calculateOffset(0, props.text.length);
    });
  }
});
</script>

<style scoped lang="scss">
.slot-box {
  display: inline-block;
}
</style>
