<template>
  <div class="card filter">
    <h4 v-if="title" class="title sle">
      {{ title }}
    </h4>
    <div class="head">
      <el-input v-model="filterText" placeholder="Search" clearable :prefix-icon="Search" />
      <el-button :icon="FolderAdd" @click="addNewProject"></el-button>
    </div>
    <div class="side-menu">
      <SideMenu :menu-list="sideList" />
    </div>
    <el-scrollbar :style="{ height: title ? `calc(100% - 95px)` : `calc(100% - 56px)` }">
      <el-tree
        ref="treeRef"
        default-expand-all
        :node-key="id"
        :data="multiple ? treeData : treeAllData"
        :show-checkbox="multiple"
        :check-strictly="false"
        :current-node-key="!multiple ? selected : ''"
        :highlight-current="!multiple"
        :expand-on-click-node="false"
        :check-on-click-node="multiple"
        :props="defaultProps"
        :filter-node-method="filterNode"
        :default-checked-keys="multiple ? selected : []"
        :icon="ArrowRightBold"
        @node-click="handleNodeClick"
        @check="handleCheckChange"
      >
        <template #default="scope">
          <span class="custom-tree-node">
            <span class="el-tree-node__label">
              <slot>
                <SvgIcon
                  :name="scope.data.icon"
                  :icon-style="{ width: '24px', height: '24px', verticalAlign: 'bottom' }"
                  v-if="scope.data.id === '0'"
                />
                <span v-if="scope.data.id === '0'" style="font-weight: 700"> {{ scope.node.label }} </span>
                <span v-else> {{ scope.node.label }} </span>
              </slot>
            </span>

            <span v-if="selected === scope.data.id + ''">
              <el-popover placement="right-start" :width="180" trigger="click">
                <template #reference>
                  <el-icon :size="12" style="transform: rotate(90deg)" @click.stop="selecteParam(scope.data)">
                    <MoreFilled />
                  </el-icon>
                </template>
                <PopoverAdd v-if="scope.data.children" :data="popoverData" :row-data="scope.data" />
                <PopoverAdd v-else :data="popoverMinData" :row-data="scope.data" />
              </el-popover>
            </span>
          </span>
        </template>
      </el-tree>
    </el-scrollbar>
  </div>
</template>
<script setup lang="ts" name="TreeFilter">
import { ref, watch, onBeforeMount, nextTick } from "vue";
import { ElTree } from "element-plus";
import { FolderAdd, Search, ArrowRightBold } from "@element-plus/icons-vue";
import PopoverAdd from "@/components/PopoverAdd/index.vue";
import SideMenu from "@/layouts/components/Menu/SideMenu.vue";
import SvgIcon from "@/components/SvgIcon/index.vue";
// 接收父组件参数并设置默认值
interface TreeFilterProps {
  requestApi?: (data?: any) => Promise<any>; // 请求分类数据的 api ==> 非必传
  data?: { [key: string]: any }[]; // 分类数据，如果有分类数据，则不会执行 api 请求 ==> 非必传
  title?: string; // treeFilter 标题 ==> 非必传
  id?: string; // 选择的id ==> 非必传，默认为 “id”
  label?: string; // 显示的label ==> 非必传，默认为 “label”
  multiple?: boolean; // 是否为多选 ==> 非必传，默认为 false
  defaultValue?: any; // 默认选中的值 ==> 非必传
}
const sideList = [
  {
    path: "/promptLibrary",
    name: "promptLibrary",
    component: "/promptLibrary/index",
    meta: {
      icon: "Library",
      title: "Prompt库",
      isLink: "",
      isHide: false,
      isFull: false,
      isAffix: false,
      isKeepAlive: true,
      badge: false,
      isShowSide: true
    }
  }
];
const props = withDefaults(defineProps<TreeFilterProps>(), {
  id: "id",
  label: "label",
  multiple: false
});

const defaultProps = {
  children: "children",
  label: props.label
};

const popoverData = [
  {
    icon: "Plus",
    title: "创建新提示词",
    fun: "addPrompt"
  },
  {
    icon: "Edit",
    title: "设为公开",
    fun: "setPublic"
  },
  {
    icon: "Edit",
    title: "编辑封面",
    fun: "editCover"
  },
  {
    icon: "Delete",
    title: "删除",
    fun: "delete"
  }
];
const popoverMinData = [
  {
    icon: "Plus",
    title: "创建副本",
    fun: "copyPrompt"
  },
  {
    icon: "Edit",
    title: "编辑封面",
    fun: "editCover"
  },
  {
    icon: "Delete",
    title: "删除",
    fun: "delete"
  }
];
console.log(popoverData, popoverMinData);
const treeRef = ref<InstanceType<typeof ElTree>>();
const treeData = ref<{ [key: string]: any }[]>([]);
const treeAllData = ref<{ [key: string]: any }[]>([]);

const selected = ref();
const setSelected = () => {
  if (props.multiple) selected.value = Array.isArray(props.defaultValue) ? props.defaultValue : [props.defaultValue];
  else selected.value = typeof props.defaultValue === "string" ? props.defaultValue : "";
};

onBeforeMount(async () => {
  setSelected();
  if (props.requestApi) {
    const { data } = await props.requestApi!();
    treeData.value = data;
    treeAllData.value = [{ id: "", [props.label]: "全部" }, ...data];
  }
});

// 使用 nextTick 防止打包后赋值不生效，开发环境是正常的
watch(
  () => props.defaultValue,
  () => nextTick(() => setSelected()),
  { deep: true, immediate: true }
);

watch(
  () => props.data,
  () => {
    if (props.data?.length) {
      treeData.value = props.data;
      // { id: "", [props.label]: "全部" },
      treeAllData.value = [...props.data];
    }
  },
  { deep: true, immediate: true }
);

const filterText = ref("");
watch(filterText, val => {
  treeRef.value!.filter(val);
});

// 过滤
const filterNode = (value: string, data: { [key: string]: any }, node: any) => {
  if (!value) return true;
  let parentNode = node.parent,
    labels = [node.label],
    level = 1;
  while (level < node.level) {
    labels = [...labels, parentNode.label];
    parentNode = parentNode.parent;
    level++;
  }
  return labels.some(label => label.indexOf(value) !== -1);
};

// emit
const emit = defineEmits<{
  change: [value: any];
  addProject: any;
}>();

// 单选
const handleNodeClick = (data: { [key: string]: any }) => {
  if (props.multiple) return;
  console.log(data);
  emit("change", data);
};

// 多选
const handleCheckChange = () => {
  emit("change", treeRef.value?.getCheckedKeys());
};

// 点击添加新作品
const addNewProject = () => {
  emit("addProject");
};
const selecteParam = (data: any) => {
  console.log(data);
};

// 暴露给父组件使用
defineExpose({ treeData, treeAllData, treeRef });
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
