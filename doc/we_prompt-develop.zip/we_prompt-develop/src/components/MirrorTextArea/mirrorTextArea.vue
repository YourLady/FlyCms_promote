<template>
  <Codemirror
    style="padding-bottom: 20px; margin-bottom: 20px; border-color: transparent"
    v-model:value="code"
    :options="cmOptions"
    border
    placeholder="test placeholder"
    :height="1300"
    @change="change"
  />
</template>

<script lang="ts" setup>
import Codemirror from "codemirror-editor-vue3";
// placeholder
import "codemirror/addon/display/placeholder.js";
// language python
import "codemirror/mode/javascript/javascript.js";
import "codemirror/mode/markdown/markdown.js";
import "codemirror/mode/python/python.js";
import "codemirror/mode/clike/clike.js";
import "codemirror/mode/xml/xml.js";
import "codemirror/mode/yaml/yaml.js";

// theme
import "codemirror/theme/dracula.css";
import "codemirror/theme/blackboard.css";
import "codemirror/theme/xq-light.css";
import "codemirror/theme/xq-dark.css";
import "codemirror/theme/oceanic-next.css";
import "codemirror/theme/vibrant-ink.css";
import "codemirror/theme/base16-dark.css";
import "codemirror/theme/base16-light.css";

import { ref, watch } from "vue";

const emit = defineEmits(["update:modelValue"]);

interface IProps {
  theme?: string;
  mode?: string;
  modelValue?: string;
  fontSize?: string;
}
// 接受的参数
const props = withDefaults(defineProps<IProps>(), {
  theme: "base16-light",
  mode: "markdown",
  modelValue: "",
  fontSize: ""
});
const code = ref(props.modelValue);

const cmOptions = ref({
  mode: "markdown", // Language mode
  theme: "base16-light", // Theme
  lineNumbers: false,
  tabSize: 2, // 制表符
  indentUnit: 2 // 缩进位数
});

watch(
  () => props.theme,
  val => {
    console.log(val);
    cmOptions.value.theme = val;
  }
);
watch(
  () => props.mode,
  val => {
    console.log(val);
    cmOptions.value.mode = val;
  }
);
watch(
  () => props.modelValue,
  val => {
    console.log(val);
    code.value = val;
  }
);

const change = (val: any) => {
  code.value = val;
  emit("update:modelValue", val);
};
defineExpose({
  change
});
</script>
<style lang="scss" scoped>
:deep(.CodeMirror-code) {
  font-size: v-bind(fontSize);
}
:deep(.CodeMirror) {
  padding: 10px;
}
:deep(.codemirror-container) {
  padding-bottom: 20px !important;
}
</style>
