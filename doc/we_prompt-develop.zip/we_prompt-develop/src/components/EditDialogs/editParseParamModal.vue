<template>
  <el-dialog v-model="visible" title="" :close-on-press-escape="false" :close-on-click-modal="false" style="max-width: 550px">
    <template #header>
      <el-icon :size="20" color="#626aef" style="margin-right: 6px; vertical-align: bottom">
        <DocumentAdd />
      </el-icon>
      <span class="download">{{ modalProps.title }}</span>
    </template>
    <el-form ref="ruleFormRef" :model="modalForm" :rules="rules" label-position="top" label-width="100px">
      <el-form-item label="作品名称" prop="title">
        <el-input v-model="modalForm.title" placeholder="作品名称" />
      </el-form-item>
      <el-form-item label="概述" prop="description">
        <el-input v-model="modalForm.description" placeholder="概述" clearable />
      </el-form-item>
      <el-form-item label="上传封面图" prop="picture">
        <div style="display: flex; align-items: center; justify-content: center; width: 100%">
          <UploadImg v-model:image-url="modalForm.picture" ref="uploadImgRef" :api="uploadPromoteImg" :type="'2'" width="250px">
            <template #empty>
              <el-icon><Picture /></el-icon>
              <span>支持格式PNG,JPG</span>
            </template>
          </UploadImg>
        </div>
      </el-form-item>
      <el-form-item label="谁能访问" prop="publicflag">
        <el-radio-group v-model="modalForm.publicflag" class="ml-4">
          <el-radio label="0" size="large">设为私密</el-radio>
          <el-radio label="1" size="large">设为公开</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="handleCancel">取消</el-button>
        <el-button type="primary" @click="handleOk(ruleFormRef)">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import useCustomModal from "@/hooks/useCustomModal";
import { ElMessage } from "element-plus";
import UploadImg from "@/components/Upload/Img.vue";
import { reactive, ref, watch } from "vue";
import type { FormInstance, FormRules } from "element-plus";
import mittBus from "@/utils/mittBus";
import { saveArticleApi } from "@/api/modules/library";
import { useUserStore } from "@/stores/modules/user";
import { uploadPromoteImg } from "@/api/modules/upload";

const userStore = useUserStore();
const ruleFormRef = ref<FormInstance>();
/** components - 基本配置 */
const modalProps = reactive({
  title: "",
  refreshList: () => {
    /*  */
  }
});
/* 初始表单 */
const initForm = {
  title: "",
  picture: "",
  description: "",
  publicflag: "0"
};
const uploadImgRef: any = ref();
const { visible, modalForm, open, close } = useCustomModal({ ...initForm });
const rules = reactive<FormRules>({
  title: [{ required: true, message: "请输入作品名称", trigger: "blur" }],
  description: [{ required: true, message: "请输入概述", trigger: "change" }],
  // picture: [{ required: true, message: "请上传封面", trigger: "change" }],
  publicflag: [{ required: true, message: "请选择是否公开", trigger: "change" }]
});
/* 关闭模态框 */
const handleCancel = () => {
  close();
};
watch(
  () => modalForm.value.picture,
  (newValue: any) => {
    console.log("newValue", newValue);
    if (newValue) {
      // modalForm.value.picture = "https://cs.prompty.top" + newValue;
    }
  },
  { deep: true }
);
/* 确认按钮 */
const handleOk = async (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  await formEl.validate(async (valid, fields) => {
    if (valid) {
      if (modalProps.title == "编辑") {
        ElMessage.success("编辑成功");
        modalProps.refreshList();
      } else {
        console.log("modalForm", modalForm.value);
        const data = saveArticleApi({
          userId: userStore.userInfo.userId,
          title: modalForm.value.title,
          picture: modalForm.value.picture.split("top")[1],
          description: modalForm.value.description,
          publicflag: Number(modalForm.value.publicflag),
          id: uploadImgRef.value.promoteObj
        });
        console.log(data);
        ElMessage.success("新增成功");
        modalProps.refreshList();
      }
      close();
    } else {
      console.log("error submit!", fields);
    }
  });
};
const openModal = (
  row: any,
  options = {
    title: "",
    refreshList: () => {
      /*  */
    }
  }
) => {
  open(row); // 打开模态框
  modalForm.value = row; // 设置表单数据
  modalProps.title = options.title; // 设置模态框标题
  modalProps.refreshList = options.refreshList; // 设置刷新列表函数
  if (options.title === "编辑") {
    modalForm.value = { ...row };
  } else {
    modalForm.value = { ...initForm, ...row };
  }
};
mittBus.on(
  "openModalFn",
  (
    row: any,
    options = {
      title: "创建新作品",
      refreshList: () => {
        /*  */
      }
    }
  ) => {
    open(row); // 打开模态框
    modalForm.value = row; // 设置表单数据
    modalProps.title = options?.title; // 设置模态框标题
    modalProps.refreshList = options.refreshList; // 设置刷新列表函数
    if (options.title === "编辑") {
      modalForm.value = { ...row };
    } else {
      modalForm.value = { ...initForm, ...row };
    }
  }
);
defineExpose({
  openModal,
  close
});
</script>

<style lang="scss" scoped>
:deep(.el-radio-group) {
  display: inline-flex;
  flex-flow: column wrap;
  align-items: flex-start;
  margin-left: 10px;
  font-size: 0;
}
</style>
