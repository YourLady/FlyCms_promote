<template>
  <div class="container">
    <el-row>
      <div style="flex-basis: 20%; margin-right: 10px" v-for="(o, index) in listData" :key="index">
        <el-card class="card-box" :body-style="{ padding: '0px' }">
          <div class="box-img" @click="toList(o)">
            <img :src="'https://cs.prompty.top' + o.picture" class="image" />
          </div>

          <div style="padding: 14px">
            <div class="title">{{ o.title }}</div>
            <div class="content">{{ o.content }}</div>
            <div class="bottom">
              <div class="time">
                <span>{{ friendlyDate(o.create_time) }}</span>
              </div>
              <!-- <el-icon class="button" color="#626aef"><MoreFilled /></el-icon> -->
              <el-popover placement="right-start" :width="180" trigger="click">
                <template #reference>
                  <el-icon :size="12" color="#626aef" class="button">
                    <MoreFilled />
                  </el-icon>
                </template>
                <PopoverAdd :data="popoverData" :row-data="o" />
              </el-popover>
            </div>
          </div>
        </el-card>
      </div>
    </el-row>
  </div>
</template>
<script setup lang="ts" name="allPrompt">
// import { ref } from "vue";
import { MoreFilled } from "@element-plus/icons-vue";
import PopoverAdd from "@/components/PopoverAdd/index.vue";
import { useRouter } from "vue-router";
const router = useRouter();

// 接收父组件参数并设置默认值
interface CardListProps {
  picture: string;
  title: string;
  create_time: string;
  content: string;
}

type Props = {
  listData: CardListProps[];
  type: string;
};
const props = defineProps<Props>();

const popoverData = [
  {
    icon: "Plus",
    title: "创建新提示词",
    fun: "addPrompt"
  },
  {
    icon: "Edit",
    title: "设为私密",
    fun: "setPublic"
  },
  {
    icon: "Edit",
    title: "编辑封面",
    fun: "editCover"
  },
  {
    icon: "Delete",
    title: "删除",
    fun: "delete"
  }
];

const toList = (item: any) => {
  console.log("-----", item);
  const row = JSON.stringify(item);
  router.push({ path: `/PromptShowList/index`, query: { row, type: props.type } });
};
const friendlyDate = (time: any) => {
  let data = new Date(time);
  let dateTimeStamp = data.getTime();
  let minute = 1000 * 60; //把分，时，天，周，半个月，一个月用毫秒表示
  let hour = minute * 60;
  let day = hour * 24;
  let week = day * 7;
  let month = day * 30;
  let year = month * 12;
  let now = new Date().getTime(); //获取当前时间毫秒
  let diffValue = now - dateTimeStamp; //时间差

  let result = "";
  if (diffValue < 0) {
    result = "" + "未来";
  }
  let minC: any = diffValue / minute; //计算时间差的分，时，天，周，月
  let hourC: any = diffValue / hour;
  let dayC: any = diffValue / day;
  let weekC: any = diffValue / week;
  let monthC: any = diffValue / month;
  let yearC: any = diffValue / year;

  if (yearC >= 1) {
    result = " " + parseInt(yearC) + "年前";
  } else if (monthC >= 1 && monthC < 12) {
    result = " " + parseInt(monthC) + "月前";
  } else if (weekC >= 1 && weekC < 5 && dayC > 6 && monthC < 1) {
    result = " " + parseInt(weekC) + "周前";
  } else if (dayC >= 1 && dayC <= 6) {
    result = " " + parseInt(dayC) + "天前";
  } else if (hourC >= 1 && hourC <= 23) {
    result = " " + parseInt(hourC) + "小时前";
  } else if (minC >= 1 && minC <= 59) {
    result = " " + parseInt(minC) + "分钟前";
  } else if (diffValue >= 0 && diffValue <= minute) {
    result = "刚刚";
  }
  console.log(result);
  return result;
};
</script>
<style scoped lang="scss">
@import "./index.scss";
</style>
