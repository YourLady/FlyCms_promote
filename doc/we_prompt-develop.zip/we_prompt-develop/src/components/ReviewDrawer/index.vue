<template>
  <el-drawer v-model="drawerVisible" title="" size="590px">
    <template #header>
      <div>
        <span>评论</span>
        <span>({{ obj!.commentList.length }})</span>
        <!--  -->
      </div>
    </template>
    <div class="message-list">
      <div class="message-item">
        <img :src="obj!.avatar" alt="" class="message-icon" />
        <div class="message-content">
          <el-input v-model="textarea1" :rows="2" type="textarea" placeholder="Write a comment..." />
        </div>
      </div>
      <div class="message-button">
        <el-button @click="cancel">取消</el-button>
        <el-button color="#626aef" @click="submit">发布</el-button>
      </div>
    </div>
    <div>
      <div class="message-list">
        <div class="message-item-other" v-for="(item, index) in obj!.commentList" :key="index">
          <img :src="item?.avatar" alt="" class="message-icon" />
          <div class="message-content-other">
            <div class="message-title">
              <span>{{ item?.userName }}</span>
              <span class="title-time">{{ item.commentTime }}</span>
            </div>
            <div class="message-date">
              <pre><code>{{ item.commentContent }}</code></pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  </el-drawer>
</template>

<script setup lang="ts">
import { ref, inject, nextTick } from "vue";
// import { storeToRefs } from "pinia";
// import { useGlobalStore } from "@/stores/modules/global";
import mittBus from "@/utils/mittBus";
import { ElMessage } from "element-plus";
import { addCommentByUser } from "@/api/modules/home";
import { useUserStore } from "@/stores/modules/user";
import { useKeepAliveStore } from "@/stores/modules/keepAlive";
import { useRoute } from "vue-router";
const userStore = useUserStore();
const keepAliveStore = useKeepAliveStore();
const route = useRoute();
console.log(route);
// 刷新当前页;
const refreshCurrentPage: Function = inject("refresh") as Function;
const refresh = () => {
  setTimeout(() => {
    keepAliveStore.removeKeepAliveName("home");
    refreshCurrentPage(false);
    nextTick(() => {
      keepAliveStore.addKeepAliveName("home");
      refreshCurrentPage(true);
    });
  }, 0);
};
interface IRowsItem {
  [propName: string]: string;
}
interface CardObjProps {
  value: any;
  collectCount: number;
  commentCount: number;
  commentList: Array<IRowsItem>;
  content: string;
  createBy: string;
  createTime: string;
  id: number;
  isPublic: number;
  likeCount: number;
  promptId: string;
  publishTime: string;
  title: string;
  updateBy: string;
  updateTime: string;
  userId: string;
  avatar: string;
  followStat: number;
  userName: string;
}
// 打开主题设置
const textarea1 = ref("");
const drawerVisible = ref(false);
const obj = ref<CardObjProps>({
  value: "",
  collectCount: 0,
  commentCount: 0,
  commentList: [],
  content: "",
  createBy: "",
  createTime: "",
  id: 0,
  isPublic: 0,
  likeCount: 0,
  promptId: "",
  publishTime: "",
  title: "",
  updateBy: "",
  updateTime: "",
  userId: "",
  avatar: "",
  followStat: 0,
  userName: ""
});

mittBus.on("openReviewDrawer", (item: any) => {
  drawerVisible.value = true;
  console.log("openReviewDrawer", item);
  textarea1.value = "";
  obj.value = item;
});
// 发布评论
const submit = async () => {
  const params = {
    userId: userStore.userInfo.userId,
    contentId: obj.value.id,
    commentContent: textarea1.value,
    userName: obj.value.userName
  };
  addCommentByUser(params).then((res: any) => {
    console.log(res);
    if (res.code == 0) {
      ElMessage.success(res.message);
      drawerVisible.value = false;
      refresh();
    }
  });
};
// 取消
const cancel = () => {
  drawerVisible.value = false;
};
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
