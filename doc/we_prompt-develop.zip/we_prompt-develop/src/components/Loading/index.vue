<template>
  <div class="loading-box">
    <div class="loading-wrap">
      <span class="dot dot-spin"><i></i><i></i><i></i><i></i></span>
    </div>
  </div>
</template>

<script setup lang="ts" name="Loading"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>
