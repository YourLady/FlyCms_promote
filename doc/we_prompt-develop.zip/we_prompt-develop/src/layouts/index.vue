<!-- 💥 这里是一次性加载 LayoutComponents -->
<template>
  <component :is="LayoutComponents[layout]" v-if="isRouterShow" />
  <ReviewDrawer />
  <!-- 弹框部分 -->
  <DialogEditParam />
</template>

<script setup lang="ts" name="layout">
import { computed, type Component, provide, ref } from "vue";
import { LayoutType } from "@/stores/interface";
import { useGlobalStore } from "@/stores/modules/global";
// import ThemeDrawer from "./components/ThemeDrawer/index.vue";
import LayoutVertical from "./LayoutVertical/index.vue";
import LayoutClassic from "./LayoutClassic/index.vue";
import LayoutTransverse from "./LayoutTransverse/index.vue";
import LayoutColumns from "./LayoutColumns/index.vue";
import LayoutPrompt from "./LayoutPrompt/index.vue";
import ReviewDrawer from "@/components/ReviewDrawer/index.vue";
import DialogEditParam from "@/components/EditDialogs/editParseParamModal.vue";

const LayoutComponents: Record<LayoutType, Component> = {
  vertical: LayoutVertical,
  classic: LayoutClassic,
  transverse: LayoutTransverse,
  columns: LayoutColumns,
  prompt: LayoutPrompt
};

const globalStore = useGlobalStore();
const layout = computed(() => globalStore.layout);
// 注入刷新页面方法
const isRouterShow = ref(true);
const refreshCurrentPage = (val: boolean) => (isRouterShow.value = val);
provide("refresh", refreshCurrentPage);
</script>

<style scoped lang="scss">
.layout {
  min-width: 600px;
  overflow: hidden;
}
</style>
