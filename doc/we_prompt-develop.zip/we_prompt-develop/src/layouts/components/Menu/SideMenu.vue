<template>
  <el-menu mode="vertical" :router="false">
    <!-- 不能直接使用 SubMenu 组件，无法触发 el-menu 隐藏省略功能 -->
    <template v-for="subItem in menuList" :key="subItem.path">
      <el-sub-menu v-if="subItem.children?.length" :key="subItem.path" :index="subItem.path + 'el-sub-menu'">
        <template #title>
          <el-icon v-if="subItem.meta.icon">
            <component :is="subItem.meta.icon"></component>
          </el-icon>
          <span>{{ subItem.meta.title }}</span>
        </template>
        <!-- <SubMenu :menu-list="subItem.children" /> -->
      </el-sub-menu>
      <el-menu-item v-else :key="subItem.path + 'el-menu-item'" :index="subItem.path" @click="handleClickMenu(subItem)">
        <el-icon v-if="subItem.meta.icon">
          <!-- <component :is="subItem.meta.icon"></component> -->
          <SvgIcon :name="subItem.meta.icon" />
        </el-icon>
        <template #title>
          <span v-if="!subItem.meta.badge" :style="{ marginLeft: subItem.meta.icon == '' ? '14px' : '', fontWeight: 700 }">
            {{ subItem.meta.title }}
          </span>
          <el-badge v-else :value="3" class="item">
            <span style="font-weight: 700">{{ subItem.meta.title }}</span>
          </el-badge>
        </template>
      </el-menu-item>
    </template>
  </el-menu>
</template>

<script setup lang="ts">
import { useRouter } from "vue-router";
import SvgIcon from "@/components/SvgIcon/index.vue";

defineProps<{ menuList: Menu.MenuOptions[] }>();

const router = useRouter();
const handleClickMenu = (subItem: Menu.MenuOptions) => {
  if (subItem.meta.isLink) return window.open(subItem.meta.isLink, "_blank");
  router.push(subItem.path);
};
</script>

<style lang="scss" scoped>
.el-sub-menu .el-sub-menu__title:hover {
  color: var(--el-menu-hover-text-color) !important;
  background-color: transparent !important;
}
.el-menu--collapse {
  .is-active {
    .el-sub-menu__title {
      color: #ffffff !important;
      background-color: var(--el-color-primary) !important;
    }
  }
}
.el-menu-item {
  height: 28px !important;
  padding-left: 0 !important;
  line-height: 0 !important;
  &:hover {
    color: var(--el-menu-hover-text-color);
    background-color: transparent !important;
  }
  &.is-active {
    color: var(--el-menu-active-color) !important;
    background-color: var(--el-menu-active-bg-color) !important;
    &::before {
      position: absolute;
      top: 0;
      bottom: 0;
      width: 4px;
      content: "";
      background-color: var(--el-color-primary);
    }
  }
  .el-icon {
    margin-left: 10px !important;
  }
}
.vertical,
.classic,
.transverse {
  .el-menu-item {
    &.is-active {
      &::before {
        left: 0;
      }
    }
  }
}
.columns {
  .el-menu-item {
    &.is-active {
      &::before {
        right: 0;
      }
    }
  }
}
.item {
  span {
    margin-right: 4px;
  }
  :deep(.el-badge__content.is-fixed) {
    right: inherit !important;
  }
}
</style>
