<template>
  <TreeFilter
    label="name"
    title=""
    :data="treeFilterData"
    :default-value="treeFilterValue.departmentId"
    @change="e => changeTreeFilter(e)"
    @add-project="addNew"
  />
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from "vue";
import { useRouter } from "vue-router";
// const route = useRoute();
const router = useRouter();
import { ElMessage } from "element-plus";
import TreeFilter from "@/components/TreeFilter/index.vue";
import { getPublicPromotesTreeList, getPrivatePromotesTreeList } from "@/api/modules/sideTree";
import { useUserStore } from "@/stores/modules/user";
// userStore.userInfo.name
const userStore = useUserStore();

defineProps<{ treeList: Menu.MenuOptions[] }>();
const treeFilterData = ref<any>([
  {
    id: "0",
    icon: "Tree1",
    name: "公开作品",
    children: [
      {
        id: "11",
        name: "研发部",
        children: [
          {
            id: "41",
            name: "研发部"
          },
          {
            id: "42",
            name: "市场部"
          },
          {
            id: "43",
            name: "商务部"
          },
          {
            id: "44",
            name: "财务部"
          }
        ]
      },
      {
        id: "12",
        name: "市场部"
      },
      {
        id: "13",
        name: "商务部"
      },
      {
        id: "14",
        name: "财务部"
      }
    ]
  },
  {
    id: "0",
    icon: "Tree1",
    name: "私人藏品",
    children: [
      {
        id: "21",
        name: "研发部",
        children: [
          {
            id: "31",
            name: "研发部"
          },
          {
            id: "32",
            name: "市场部"
          },
          {
            id: "33",
            name: "商务部"
          },
          {
            id: "34",
            name: "财务部"
          }
        ]
      },
      {
        id: "22",
        name: "市场部"
      },
      {
        id: "23",
        name: "商务部"
      },
      {
        id: "24",
        name: "财务部"
      }
    ]
  }
]);
const treeFilterValue = reactive({ departmentId: "1" });
const changeTreeFilter = (val: { [key: string]: any }) => {
  console.log(val);
  treeFilterValue.departmentId = val.id;

  if (val && val.children && val.children.length > 0) {
    // 跳转到prompt库
    let index = 0;
    if (val.name == "私人藏品") {
      index = 2;
    } else {
      index = 1;
    }
    router.push({
      path: "/promptLibrary",
      query: { currentIndex: index }
    });
    return;
  } else {
    ElMessage.success(`你选择了 id 为 ${val.id} 的数据🤔`);
    router.push(`/assembly/tabs/detail`);
  }
};
const addNew = () => {
  console.log("调用新增作品组件");
  // 调用新增作品组件
};
const getPublicTreeList = () => {
  getPublicPromotesTreeList(userStore.userInfo.shortUrl).then((res: any) => {
    console.log(res);
  });
};
const getPrivateTreeList = () => {
  getPrivatePromotesTreeList(userStore.userInfo.shortUrl).then((res: any) => {
    console.log(res);
  });
};
onMounted(() => {
  getPublicTreeList();
  getPrivateTreeList();
});
</script>

<style lang="scss" scoped></style>
