<template>
  <div class="tool-bar-lf">
    <el-input v-model="searchValue" class="w-50 m-2" placeholder="Search" :prefix-icon="Search" />
  </div>
</template>

<script setup lang="ts">
import { ref, watch, nextTick, onMounted } from "vue";
import { Search } from "@element-plus/icons-vue";
import { useRouter } from "vue-router";
const router = useRouter();
const searchValue = ref("");
onMounted(() => {
  // 监听 enter 事件（调用登录）
  document.onkeydown = (e: KeyboardEvent) => {
    e = (window.event as KeyboardEvent) || e;
    if (e.code === "Enter" || e.code === "enter" || e.code === "NumpadEnter") {
      if (searchValue.value && searchValue.value !== "") {
        router.push({
          path: "/globalSearch/index",
          query: { searchValue: searchValue.value }
        });
      }
    }
  };
});
// 全局搜索要调用接口
watch(
  () => searchValue.value,
  newValue => {
    newValue &&
      nextTick(() => {
        setTimeout(() => {
          // router.push({
          //   path: "/globalSearch/index",
          //   query: { searchValue: newValue }
          // });
        }, 1000);
      });
  },
  {
    immediate: true
  }
);
</script>

<style scoped lang="scss">
.tool-bar-lf {
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  white-space: nowrap;
  :deep(.el-input__wrapper) {
    font-family: ABeeZee;
    font-size: 16px;
    font-weight: 400;
    line-height: 26px;
    background: var(--search-color);
    border-width: 0;
    border-radius: 22px;
    outline: none;
    box-shadow: none;
  }
}
</style>
