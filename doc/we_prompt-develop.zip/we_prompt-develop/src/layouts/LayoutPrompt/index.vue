<!-- 横向布局 -->
<template>
  <el-container class="layout">
    <el-header>
      <div class="logo flx-center">
        <img class="logo-img" src="@/assets/images/logo.png" alt="logo" @click="toPrompt" />
        <!-- <span class="logo-text">{{ title }}</span> -->
      </div>
      <ToolBarLeftSearch />
      <el-menu mode="horizontal" :router="false" :default-active="activeMenu">
        <!-- 不能直接使用 SubMenu 组件，无法触发 el-menu 隐藏省略功能 -->
        <template v-for="subItem in menuList" :key="subItem.path">
          <el-sub-menu v-if="subItem.children?.length" :key="subItem.path" :index="subItem.path + 'el-sub-menu'">
            <template #title>
              <span>{{ subItem.meta.title }}</span>
            </template>
            <SubMenu :menu-list="subItem.children" />
          </el-sub-menu>
          <el-menu-item v-else :key="subItem.path + 'el-menu-item'" :index="subItem.path" @click="handleClickMenu(subItem)">
            <template #title>
              <span>{{ subItem.meta.title }}</span>
            </template>
          </el-menu-item>
        </template>
      </el-menu>
      <ToolBarRight />
    </el-header>
    <el-container class="classic-content">
      <el-aside :class="[show_side ? 'show' : 'hide']">
        <div class="aside-box" :style="{ width: '280px' }">
          <el-scrollbar>
            <div class="side-menu">
              <SideMenu :menu-list="sideList" />
            </div>
            <div class="side-library">
              <SideTree :tree-list="treeList" />
            </div>
          </el-scrollbar>
        </div>
      </el-aside>
      <el-container class="classic-main">
        <Main />
      </el-container>
    </el-container>
  </el-container>
</template>

<script setup lang="ts" name="layoutTransverse">
import { computed } from "vue";
import { useAuthStore } from "@/stores/modules/auth";
import { useRoute, useRouter } from "vue-router";
import Main from "@/layouts/components/Main/index.vue";
import ToolBarRight from "@/layouts/components/Header/ToolBarRight.vue";
import ToolBarLeftSearch from "@/layouts/components/Header/ToolBarLeftSearch.vue";
import SubMenu from "@/layouts/components/Menu/SubMenu.vue";
import SideMenu from "@/layouts/components/Menu/SideMenu.vue";
import SideTree from "@/layouts/components/Menu/SideTree.vue";

// const title = import.meta.env.VITE_GLOB_APP_TITLE;
const route = useRoute();
const router = useRouter();
const authStore = useAuthStore();
const menuList = computed(() => authStore.showMenuListGet);
const activeMenu = computed(() => (route.meta.activeMenu ? route.meta.activeMenu : route.path) as string);
const sideList = computed(() => authStore.showSideListGet);
const show_side = computed(() => (route.meta.isShowSide ? route.meta.isShowSide : false) as string);
const treeList: any = [];

const handleClickMenu = (subItem: Menu.MenuOptions) => {
  if (subItem.meta.isLink) return window.open(subItem.meta.isLink, "_blank");
  router.push(subItem.path);
};
const toPrompt = () => {
  router.push("/promptLibrary");
};
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
