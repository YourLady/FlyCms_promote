import { ref } from "vue";

/* 自定义模态框常用数据类型变量统一生成hooks */
function useCustomModal<T extends Record<string, any>>(initForm: any) {
  const visible = ref(false);
  const loading = ref(false);
  const record = ref<T>();
  const modalForm = ref(initForm);
  const modalFormRef = ref<null>(null);

  const open = (data: T | undefined | null) => {
    visible.value = true;
    if (!data) {
      record.value = initForm;
      modalForm.value = initForm;
    } else {
      record.value = data;
      modalForm.value = data;
    }
  };

  const close = () => {
    visible.value = false;
    record.value = {} as T;
  };
  return {
    visible,
    loading,
    record,
    modalForm,
    modalFormRef,
    open,
    close
  };
}

export default useCustomModal;
