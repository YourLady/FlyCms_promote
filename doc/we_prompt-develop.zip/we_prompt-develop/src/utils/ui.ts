import { ElMessage } from "element-plus";
/**
 * toast
 * @param msg toast内容
 */
export function toast(msg: string) {
  ElMessage({
    message: msg,
    type: "success"
  });
}

/**
 * toast
 * @param msg toast内容
 */
export function toastError(msg: string) {
  ElMessage({
    message: msg,
    type: "error"
  });
}
