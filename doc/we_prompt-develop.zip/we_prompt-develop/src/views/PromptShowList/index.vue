<template>
  <div class="container-box">
    <div class="content-head">
      <div :class="['breadcrumb-box mask-image no-icon']">
        <el-breadcrumb :separator-icon="ArrowRight">
          <transition-group name="breadcrumb">
            <el-breadcrumb-item v-for="(item, index) in breadcrumbList" :key="item.path">
              <div class="el-breadcrumb__inner is-link" @click="onBreadcrumbClick(item, index)">
                <!-- <el-icon v-show="item.meta.icon && globalStore.breadcrumbIcon" class="breadcrumb-icon">
                  <component :is="item.meta.icon"></component>
                </el-icon> -->
                <span class="breadcrumb-title">{{ item.title }}</span>
              </div>
            </el-breadcrumb-item>
          </transition-group>
        </el-breadcrumb>
      </div>
    </div>
    <div class="container">
      <div style="margin-top: 10px">
        <el-table
          :data="tableData"
          @row-click="clickRow"
          :cell-style="{ 'text-align': 'center' }"
          :header-cell-style="{ background: '#eef1f6', color: '#606266', 'text-align': 'center' }"
          style="width: 755px"
          height="650"
        >
          <el-table-column prop="title" label="Prompt 名称" width="180" />
          <el-table-column prop="token" label="token数" width="180" />
          <el-table-column prop="createTime" label="更新时间">
            <template #default="{ row }">
              <div>
                <span>{{ timestampToTime(row.createTime) }}</span>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts" name="userInfo">
import { ref, onMounted, onBeforeMount } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ArrowRight } from "@element-plus/icons-vue";
import { findPromoteArticleListById } from "@/api/modules/library";
import { useUserStore } from "@/stores/modules/user";
// import { Sort, Bottom } from "@element-plus/icons-vue";
// import { useGlobalStore } from "@/stores/modules/global";
// const globalStore = useGlobalStore();
const route = useRoute();
const router = useRouter();
const userStore = useUserStore();

const breadcrumb = ref(false);
onBeforeMount(() => {
  console.log(route.query);
  const row = JSON.parse(route.query.row as any);
  if (route.query.type == "1") {
    breadcrumbList.value[0].title = userStore.userInfo.userName;
    breadcrumbList.value[0].path = "/promptLibrary";
    breadcrumbList.value[1].title = row.title;
  } else if (route.query.type == "2") {
    breadcrumbList.value[1].title = row.title;
  } else {
    breadcrumbList.value[0].title = route.query.type;
    breadcrumbList.value[1].title = row.title;
  }
});
onMounted(() => {
  breadcrumb.value = true;
  getList();
});
const breadcrumbList: any = ref([
  { title: "收藏", path: "/assembly/library/index" },
  { title: "Cool Teacher", path: "" }
]);
// const tableData = [
//   {
//     date: "2016-05-03",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-02",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-04",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-01",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-08",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-06",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-07",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-03",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-02",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-04",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-01",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-08",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-06",
//     name: "Tom",
//     token: "1023 token"
//   },
//   {
//     date: "2016-05-07",
//     name: "Tom",
//     token: "1023 token"
//   }
// ];
const tableData = ref([]);
// Click Breadcrumb
const onBreadcrumbClick = (item: any, index: number) => {
  if (index !== breadcrumbList.value.length - 1) router.push(item.path);
};
const clickRow = (row: any) => {
  console.log(row);
  router.push({
    path: `/assembly/tabs/detail`,
    query: { row: JSON.stringify(row), type: "views" }
  });
};
const getList = () => {
  const row = JSON.parse(route.query.row as any);
  console.log(row.promoteid);
  findPromoteArticleListById(row?.promoteid).then((res: any) => {
    console.log(res);
    if (res.code == 0) {
      tableData.value = res.data;
    }
  });
};
// 时间戳转换时间格式YYYY-MM-DD hh:mm:ss
const timestampToTime = (timestamp: any) => {
  if (timestamp == null) {
    return "";
  } else {
    const date = new Date(timestamp);
    const y = date.getFullYear(); // 年
    let MM: any = date.getMonth() + 1; // 月
    MM = MM < 10 ? "0" + MM : MM;
    let d: any = date.getDate(); // 日
    d = d < 10 ? "0" + d : d;
    let h: any = date.getHours(); // 时
    h = h < 10 ? "0" + h : h;
    let m: any = date.getMinutes(); // 分
    m = m < 10 ? "0" + m : m;
    let s: any = date.getSeconds(); // 秒
    s = s < 10 ? "0" + s : s;
    return y + "-" + MM + "-" + d + " " + h + ":" + m + ":" + s;
  }
};
</script>
<style lang="scss" scoped>
@import "./index.scss";
</style>
