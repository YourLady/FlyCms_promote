<template>
  <div class="home card">
    <div class="header">
      <div class="header-left">
        <div class="avatar">
          <img src="@/assets/images/avatar.gif" alt="avatar" />
        </div>
      </div>
      <div class="header-right">
        <div class="header-title">{{ userStore.userInfo.userName }}</div>
        <div class="header-title-control">
          <span>3.4k</span>
          <span style="margin-left: 6px">收藏</span>
          <span style="margin-left: 16px">10</span>
          <span style="margin-left: 6px">关注</span>
        </div>
        <div class="header-title-works">
          <span>123</span>
          <span style="margin-left: 6px">作品</span>
        </div>
      </div>
      <div class="share">
        <el-button :icon="Promotion" color="#626aef">Share</el-button>
      </div>
    </div>
    <div class="container">
      <div class="content-head">
        <div class="add-content">
          <div style="padding-bottom: 6px"><el-button round :icon="CirclePlus" @click="createNew">创建新作品</el-button></div>
        </div>
        <div class="card-tabs">
          <div class="tabs-item" v-for="(item, index) in tabsList" :key="index" :class="{ active: currentIndex === index }">
            <div @click="handleClick(index)">{{ item.label }}</div>
          </div>
        </div>
        <div class="content-sort">
          <div style="padding-bottom: 6px">
            <el-button round :icon="Sort">
              排序:最近更新
              <el-icon class="el-icon--right"><Bottom /> </el-icon>
            </el-button>
          </div>
        </div>
      </div>
      <div class="content">
        <PromptList :list-data="list" :type="'1'" />
      </div>
    </div>
    <!-- 弹框部分 -->
    <!-- <DialogEditParam ref="dialogEditParamRef" /> -->
  </div>
</template>

<script setup lang="ts" name="promptLibrary">
import { ref, onMounted } from "vue";
import { Promotion, CirclePlus, Sort, Bottom } from "@element-plus/icons-vue";
import PromptList from "@/components/PromptList/index.vue";
// import DialogEditParam from "@/components/EditDialogs/editParseParamModal.vue";
import png1 from "@/assets/images/png1.png";
import png2 from "@/assets/images/png2.png";
import png3 from "@/assets/images/png3.png";
import png4 from "@/assets/images/png4.png";
import mittBus from "@/utils/mittBus";
import { useRoute } from "vue-router";
import { useUserStore } from "@/stores/modules/user";
// userStore.userInfo.name
const userStore = useUserStore();
import { getAllArticleList, getPromotesArticleList, getNoPromotesList } from "@/api/modules/library";

const route = useRoute();
const tabsList = [
  {
    label: "ALL",
    name: "stroll"
  },
  {
    label: "公开作品",
    name: "follow"
  },
  {
    label: "私人藏品",
    name: "mine"
  }
];
const list: any = ref([]);
// const dialogEditParamRef = ref<any>();
const currentIndex = ref(0);
const handleClick = (index: any) => {
  console.log("index", index);
  currentIndex.value = index;
  if (index === 0) {
    getAllList();
  }
  if (index === 1) {
    getPromotesList();
  }
  if (index === 2) {
    getNoPromotesArticleList();
  }
};
const createNew = () => {
  mittBus.emit("openModalFn", {
    row: {
      remark: null,
      worksName: "",
      avatar: null,
      zhValue: "1"
    },
    options: {
      title: "创建新作品",
      refreshList: updateParentNode
    }
  });
};
const updateParentNode = () => {
  console.log("updateParentNode");
};
onMounted(() => {
  console.log(route.query);
  if (route.query.currentIndex) {
    currentIndex.value = Number(route.query.currentIndex);
  }
  getAllList();
});
// 获取所有作品list
const getAllList = () => {
  getAllArticleList(userStore.userInfo.shortUrl)
    .then((res: any) => {
      console.log(res);
      console.log("userStore.userInfo.userId", userStore.userInfo.userId);
      list.value = res.data[userStore.userInfo.userId];
    })
    .catch(() => {
      list.value = [
        {
          avatar: png1,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "30min"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        }
      ];
    });
};
// 获取公开作品
const getPromotesList = () => {
  getPromotesArticleList(userStore.userInfo.shortUrl)
    .then((res: any) => {
      console.log(res);
      list.value = res.data[userStore.userInfo.userId];
    })
    .catch(() => {
      list.value = [
        {
          avatar: png1,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "30min"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        }
      ];
    });
};
// 获取不公开作品列表
const getNoPromotesArticleList = () => {
  getNoPromotesList(userStore.userInfo.shortUrl)
    .then((res: any) => {
      console.log(res);
      list.value = res.data[userStore.userInfo.userId];
    })
    .catch(() => {
      list.value = [
        {
          avatar: png1,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "30min"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "15min"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "2h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "3h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        }
      ];
    });
};
// provide("createNew", createNew);
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
