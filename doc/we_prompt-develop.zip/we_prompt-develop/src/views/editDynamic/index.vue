<template>
  <div class="content-box">
    <div class="head">
      <span>编辑动态</span>
    </div>
    <div class="line"></div>
    <div class="container">
      <el-input v-model="textarea" :autosize="{ minRows: 8, maxRows: 8 }" type="textarea"></el-input>
      <div class="select-tree">
        <el-tree-select v-model="value" :data="data" :render-after-expand="false" placeholder="导入提示词" :icon="ArrowRightBold">
          <template #prefix>
            <el-icon><Download /></el-icon>
          </template>
        </el-tree-select>
      </div>
      <div class="select-container"></div>
      <div class="footer">
        <el-button @click="open">取消</el-button>
        <el-button type="primary">发布</el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts" name="userInfo">
import { ref } from "vue";
// import { HOME_URL } from "@/config";
// import { useRoute, useRouter } from "vue-router";
// import { useTabsStore } from "@/stores/modules/tabs";
// import { useGlobalStore } from "@/stores/modules/global";
// import { useKeepAliveStore } from "@/stores/modules/keepAlive";
// import { Edit } from "@element-plus/icons-vue/dist/types";
import { ArrowRightBold } from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";
import type { Action } from "element-plus";

const textarea = ref("");
const value = ref("");
const data = [
  {
    value: "1",
    label: "Level one 1",
    children: [
      {
        value: "1-1",
        label: "Level two 1-1",
        children: [
          {
            value: "1-1-1",
            label: "Level three 1-1-1"
          }
        ]
      }
    ]
  },
  {
    value: "2",
    label: "Level one 2",
    children: [
      {
        value: "2-1",
        label: "Level two 2-1",
        children: [
          {
            value: "2-1-1",
            label: "Level three 2-1-1"
          }
        ]
      },
      {
        value: "2-2",
        label: "Level two 2-2",
        children: [
          {
            value: "2-2-1",
            label: "Level three 2-2-1"
          }
        ]
      }
    ]
  },
  {
    value: "3",
    label: "Level one 3",
    children: [
      {
        value: "3-1",
        label: "Level two 3-1",
        children: [
          {
            value: "3-1-1",
            label: "Level three 3-1-1"
          }
        ]
      },
      {
        value: "3-2",
        label: "Level two 3-2",
        children: [
          {
            value: "3-2-1",
            label: "Level three 3-2-1"
          }
        ]
      }
    ]
  }
];

const open = () => {
  ElMessageBox.alert("如果您取消，编辑的内容会被丢弃，是否继续？", "温馨提示", {
    // if you want to disable its autofocus
    showCancelButton: true,
    confirmButtonText: "确定",
    cancelButtonText: "暂不取消",
    callback: (action: Action) => {
      ElMessage({
        type: "info",
        message: `action: ${action}`
      });
    }
  });
};
</script>
<style lang="scss" scoped>
@import "./index.scss";
</style>
