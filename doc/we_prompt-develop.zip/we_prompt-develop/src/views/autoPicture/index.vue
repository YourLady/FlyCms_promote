<template>
  <div class="swiper">
    <div class="capture" id="capture">
      <div class="pic-content">
        <div class="pic-head">
          <el-divider style="width: 50%" />
          <img src="@/assets/images/white-icon.png" alt="avatar" />
        </div>
        <div class="content">
          <pre
            style="
              font-size: 24px;
              font-weight: 400;
              line-height: 31.82px;
              color: rgb(255 255 255 / 100%);
              letter-spacing: 0;
              white-space: pre-wrap;
            "
          ><code ># Role:知识探索专家
## Profile:
- author: Arthur
- version: 0.8
- language: 中文
- description: 我是一个专门用于提问并解答有关特定知识点的 AI 角色。

## Goals:
提出并尝试解答有关用户指定知识点的三个关键问题：其来源、其本质、其发展。

## Constrains:
1. 对于不在你知识库中的信息, 明确告知用户你不知道
2. 你不擅长客套, 不会进行没有意义的夸奖和客气对话
3. 解释完概念即结束对话, 不会询问是否有其它问题

## Skills:
1. 具有强大的知识获取和整合能力
2. 拥有广泛的知识库, 掌握提问和回答的技巧
3. 拥有排版审美, 会利用序号, 缩进, 分隔线和换行符等等来美化信息排版
4. 擅长使用比喻的方式来让用户理解知识

## Workflows:
你会按下面的框架来扩展用户提供的概念, 并通过分隔符, 序号, 缩进, 换行符等进行排版美化

1．它从哪里来？
- 讲解清楚该知识的起源, 它是为了解决什么问题而诞生。
- 然后对比解释一下: 它出现之前是什么状态, 它出现之后又是什么状态?

2．它是什么？
- 讲解清楚该知识本身，它是如何解决相关问题的?
- 再说明一下: 应用该知识时最重要的三条原则是什么?
- 接下来举一个现实案例方便用户直观理解:
- 案例背景情况(遇到的问题)
- 使用该知识如何解决的问题

3．它到哪里去？
- 它的局限性是什么?
- 当前行业对它的优化方向是什么?
- 未来可能的发展方向是什么?

# Initialization:
作为知识探索专家，我拥有广泛的知识库和问题提问及回答的技巧，严格遵守尊重用户和提供准确信息的原则。
我会使用默认的中文与您进行对话，首先我会友好地欢迎您，然后会向您介绍我自己以及我的工作流程。</code></pre>
          <el-divider style="width: 50%; margin-top: 60px" />
        </div>
      </div>
      <div class="footer">
        <div class="footer-left">
          <div class="img">
            <img src="https://img.js.design/assets/img/654646c6e68d83782579cf5a.png#340c4fe6cca154daabc488dce7ae18f0" alt="" />
          </div>
          <div class="tips">
            <div style="margin-bottom: 10px">「知识探索专家」 Ver.0.8</div>
            <div style="text-indent: 12px">作者：李继刚</div>
          </div>
        </div>
        <div class="footer-right">
          <img src="https://img.js.design/assets/img/654646c6572d7c6d81824f21.png#f14650dc448ba67a17b29d2f00e89092" alt="" />
        </div>
      </div>
      <div class="footer-icon">
        <img src="@/assets/images/black-icon.png" alt="avatar" />
        <div>www.we-prompt.cn</div>
      </div>
    </div>
    <div @click="shareImg" style="height: 100px">点击分享</div>
  </div>
</template>

<script setup lang="ts">
import { useAutoPicture } from "@/hooks/useAutoPicture";
import { ref } from "vue";

const show = ref(false);
const currentImg = ref();

const shareImg = async (index: any) => {
  console.log("index:", index);
  const el = document.getElementById(`capture`) as HTMLElement;
  console.log("el:", el);
  // const canvasFalse = document.createElement('canvas')
  const width = parseInt(window.getComputedStyle(el).width);
  const height = parseInt(window.getComputedStyle(el).height);
  console.log("width:", width, "height:", height);
  let canvas = await useAutoPicture(`capture`, { width, height });
  if (canvas) {
    currentImg.value = canvas;
    show.value = true;
    // canvas为转换后的Canvas对象
    let oImg = new Image();
    oImg = currentImg.value; // 导出图片
    console.log(oImg);
    let oA = document.createElement("a") as any;
    oA.download = "分享内容"; // 设置下载的文件名，默认是'下载'
    oA.href = oImg;
    document.body.appendChild(oA);
    oA.click();
    oA.remove(); // 下载之后把创建的元素删除
  }
};
</script>

<style lang="scss" scoped>
.capture {
  box-sizing: border-box;
  width: 1000px;
  padding: 45px;

  // height: 400px;
  background: #ffffff;
  .pic-content {
    padding: 52px;
    background: rgb(23 25 37 / 100%);
    .pic-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      img {
        width: 96px;
        height: 80px;
        margin-left: 10px;
      }
    }
  }
  .footer {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    .footer-left {
      display: flex;
      align-items: center;
      height: 98px;
      .img {
        padding-right: 20px;
        margin-right: 10px;
        border-right: 2px solid;
        img {
          width: 70px;
          height: 70px;
        }
      }
      .tips {
        font-size: 24px;
        font-weight: 600;
        line-height: 31.82px;
        color: rgb(0 0 0 / 100%);
        text-align: left;
        letter-spacing: 0;
        vertical-align: middle;
      }
    }
    .footer-right {
      img {
        width: 98px;
        height: 98px;
      }
    }
  }
  .footer-icon {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
    font-size: 20px;
    font-weight: 400;
    line-height: 26.52px;
    color: rgb(0 0 0 / 100%);
    letter-spacing: 0;
    img {
      width: 86px;
      height: 81px;
    }
  }
}
</style>
