<template>
  <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" size="large" style="width: 100%">
    <!-- <el-form-item prop="username" v-if="userStore.userStatus">
      <el-input v-model="loginForm.username" placeholder="用户名：admin / user">
        <template #prefix>
          <el-icon class="el-input__icon">
            <user />
          </el-icon>
        </template>
      </el-input>
    </el-form-item> -->
    <el-form-item prop="phone">
      <el-input v-model="loginForm.phone" placeholder="手机号：admin / user">
        <template #prefix>
          <el-icon class="el-input__icon">
            <Iphone />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="code" v-if="userStore.userStatus">
      <el-input v-model="loginForm.captcha" placeholder="验证码">
        <template #append>
          <el-button type="primary" v-if="showCode" class="code_type" @click.stop="sendVerificationCode"> 发送验证码 </el-button>
          <el-button type="primary" class="code_type" v-if="!showCode" disabled> {{ count }}秒后重发 </el-button>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="password" :style="{ marginBottom: !userStore.userStatus ? '10px' : '' }">
      <el-input v-model="loginForm.password" type="password" placeholder="密码：123456" show-password autocomplete="new-password">
        <template #prefix>
          <el-icon class="el-input__icon">
            <lock />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
  </el-form>
  <div class="login-btn-tips" v-show="!userStore.userStatus">
    <el-checkbox v-model="checkedPassWord" label="记住密码" size="large" />
    <el-button size="large" link :loading="loading" @click="login(loginFormRef)"> 忘记密码? </el-button>
  </div>
  <div class="login-btn">
    <el-button v-if="!userStore.userStatus" size="large" type="primary" :loading="loading" @click="login(loginFormRef)">
      登录
    </el-button>
    <el-button v-if="userStore.userStatus" size="large" type="primary" :loading="loading" @click="register(loginFormRef)">
      注册
    </el-button>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from "vue";
import { useRouter } from "vue-router";
import { HOME_URL } from "@/config";
import { getTimeState, localSet, localGet } from "@/utils";
import { Login } from "@/api/interface";
import { ElNotification } from "element-plus";
import { loginApi, registerApi, getRegisterMobileCode } from "@/api/modules/login"; // loginApi,
import { useUserStore } from "@/stores/modules/user";
import { useTabsStore } from "@/stores/modules/tabs";
import { useKeepAliveStore } from "@/stores/modules/keepAlive";
import { initDynamicRouter } from "@/routers/modules/dynamicRouter";
// import { UserFilled } from "@element-plus/icons-vue";
import type { ElForm } from "element-plus";
// import md5 from "md5";

const router = useRouter();
const userStore = useUserStore();
const tabsStore = useTabsStore();
const keepAliveStore = useKeepAliveStore();

type FormInstance = InstanceType<typeof ElForm>;
const loginFormRef = ref<FormInstance>();
const loginRules = reactive({
  username: [{ required: true, message: "请输入用户名", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }],
  phone: [{ required: true, message: "请输入手机号", trigger: "blur" }],
  captcha: [{ required: true, message: "请输入验证码", trigger: "blur" }]
});

const loading = ref(false);
const loginForm = reactive<Login.LoginForm>({
  username: "",
  password: "",
  phone: "",
  captcha: "",
  rememberMe: "",
  redirectUrl: ""
});
const checkedPassWord = ref(false);

//验证码 倒计时
const showCode = ref(true);
const count = ref();
const timer = ref();
const sendVerificationCode = () => {
  let TIME_COUNT = 60;
  if (!timer.value) {
    count.value = TIME_COUNT;
    showCode.value = false;
    timer.value = setInterval(() => {
      if (count.value > 0 && count.value <= TIME_COUNT) {
        count.value--;
      } else {
        showCode.value = true;
        clearInterval(timer.value);
        timer.value = null;
      }
    }, 1000);
    getCode();
  }
};
const getCode = async () => {
  // /ucenter/safemobilecode
  const { data } = await getRegisterMobileCode(loginForm.phone);
  console.log(data);
};

// login
const login = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate(async valid => {
    if (!valid) return;
    loading.value = true;
    try {
      // 1.执行登录接口username password rememberMe redirectUrl captcha
      const params = {
        username: loginForm.phone,
        password: loginForm.password,
        rememberMe: "0"
        // redirectUrl: "/home/index",
        // captcha: ""
      };
      console.log(params);
      const { data } = await loginApi(params);
      console.log(data);
      // userStore.setToken("bqddxxwqmfncffacvbpkuxvwvqrhln");
      userStore.setToken(data.sessionKey);

      userStore.setUserInfo({ ...data, avatar: `https://cs.prompty.top` + data.avatar });
      // 2.添加动态路由
      await initDynamicRouter();

      // 3.清空 tabs、keepAlive 数据
      tabsStore.setTabs([]);
      keepAliveStore.setKeepAliveName([]);

      // 4.跳转到首页
      router.push(HOME_URL);
      ElNotification({
        title: getTimeState(),
        message: "欢迎登录",
        type: "success",
        duration: 3000
      });
      // 判断是否记住密码
      if (checkedPassWord.value) {
        localSet("loginForm", loginForm);
      } else {
        localSet("loginForm", {});
      }
    } finally {
      loading.value = false;
    }
  });
};
// register
const register = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate(async valid => {
    if (!valid) return;
    loading.value = true;
    try {
      // 1.执行注册接口
      const param = {
        username: loginForm.phone,
        password: loginForm.password,
        code: loginForm.captcha
      };
      console.log(param);
      // { ...loginForm, password: md5(loginForm.password) }
      const { data } = await registerApi(param);
      console.log(data);
      // userStore.setToken(data.sessionKey);

      // 2.添加动态路由
      // await initDynamicRouter();

      // 3.清空 tabs、keepAlive 数据
      tabsStore.setTabs([]);
      keepAliveStore.setKeepAliveName([]);

      // 4.跳转到登录
      // router.push(HOME_URL);
      userStore.changeStatus(false);
      userStore.changeWxStatus(false);
      ElNotification({
        title: getTimeState(),
        message: "注册成功",
        type: "success",
        duration: 3000
      });
    } finally {
      loading.value = false;
    }
  });
};

// resetForm
// const resetForm = (formEl: FormInstance | undefined) => {
//   if (!formEl) return;
//   formEl.resetFields();
// };

onMounted(() => {
  if (localGet("loginForm") !== null && Object.keys(localGet("loginForm")).length > 2) {
    checkedPassWord.value = true;
    const userPassword = localGet("loginForm");
    loginForm.password = userPassword.password;
    loginForm.phone = userPassword.phone;
  }
  // 监听 enter 事件（调用登录）
  document.onkeydown = (e: KeyboardEvent) => {
    e = (window.event as KeyboardEvent) || e;
    if (e.code === "Enter" || e.code === "enter" || e.code === "NumpadEnter") {
      if (loading.value) return;
      login(loginFormRef.value);
    }
  };
});
</script>

<style scoped lang="scss">
@import "../index.scss";
</style>
