<template>
  <div class="login-container flx-center">
    <div class="login-box">
      <!-- <SwitchDark class="dark" /> -->
      <div class="login-left">
        <div class="login-head">
          <div class="login-logo">
            <!-- <SvgIcon name="logo" /> -->
            <img class="login-icon" src="@/assets/images/logo.png" alt="" />
          </div>
          <div class="head-text" v-if="!userStore.userStatus">
            <span>还没有账号?</span>
            <span class="head-a" @click="changeStatus(true)">注册</span>
          </div>
          <div class="head-text" v-if="userStore.userStatus">
            <span>已有账号?</span>
            <span class="head-a" @click="changeStatus(false)">登录</span>
          </div>
        </div>
        <div class="login-content">
          <div class="login-form">
            <div class="login-logo" v-if="!userStore.userStatus && !userStore.wxStatus">
              <h2 class="logo-text">登录</h2>
            </div>
            <div class="login-logo" v-if="userStore.userStatus && !userStore.wxStatus">
              <h2 class="logo-text">创建账户</h2>
            </div>
            <div class="login-logo" v-if="userStore.wxStatus">
              <h2 class="logo-text">微信扫码登录</h2>
            </div>
            <LoginForm v-if="!userStore.wxStatus" />
            <LoginWx v-if="userStore.wxStatus" />
            <div class="login-wx" v-if="!userStore.wxStatus">
              <i :class="'iconfont icon-weixin'" @click="changeWx(true)"></i>
              <span style="font-size: 14px">微信扫码快速登录</span>
            </div>
            <div class="login-wx" v-if="userStore.wxStatus">
              <i :class="'iconfont icon-shouji'" @click="changeWx(false)"></i>
              <span style="font-size: 14px">使用手机号登录</span>
            </div>
          </div>
        </div>
        <div class="footer flx-center">
          <a href="https://beian.miit.gov.cn/" target="_blank"> 蒙ICP备2023002496号-1 </a>
        </div>
      </div>

      <div class="login-right">
        <img class="login-right-img" src="@/assets/images/login_right.png" alt="login" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts" name="login">
import LoginForm from "./components/LoginForm.vue";
// import SwitchDark from "@/components/SwitchDark/index.vue";
import { useUserStore } from "@/stores/modules/user";
import LoginWx from "./components/LoginWx.vue";
// import SvgIcon from "@/components/SvgIcon/index.vue";
const userStore = useUserStore();
const changeStatus = (val: boolean) => {
  userStore.changeStatus(val);
  userStore.changeWxStatus(false);
};
const changeWx = (val: boolean) => {
  userStore.changeWxStatus(val);
  userStore.changeStatus(false);
};
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
