<template>
  <div class="main">
    <div class="title">Prompt Diff 工具</div>
    <div class="head">
      <div class="left">
        <div class="select-tree" style="margin-right: 38px">
          <el-tree-select
            v-model="value1"
            :data="data"
            :render-after-expand="false"
            placeholder="导入提示词"
            :icon="ArrowRightBold"
          >
            <template #prefix>
              <el-icon><Download /></el-icon>
            </template>
          </el-tree-select>
        </div>
      </div>
      <div class="right">
        <div class="select-tree">
          <el-tree-select
            v-model="value1"
            :data="data"
            :render-after-expand="false"
            placeholder="导入提示词"
            :icon="ArrowRightBold"
          >
            <template #prefix>
              <el-icon><Download /></el-icon>
            </template>
          </el-tree-select>
        </div>
      </div>
    </div>
    <Codemirror merge :options="cmOptions" :height="400" @change="onChange" />
  </div>
</template>

<script lang="ts">
import { ref, defineComponent, reactive } from "vue";
// import { MergeView } from "codemirror/addon/merge/merge";
// import type { Editor } from "codemirror";
import { ArrowRightBold } from "@element-plus/icons-vue";
import Codemirror from "codemirror-editor-vue3";

import "codemirror/mode/htmlmixed/htmlmixed.js";
// placeholder
import "codemirror/addon/display/placeholder.js";
// language python
import "codemirror/mode/javascript/javascript.js";
import "codemirror/mode/markdown/markdown.js";
import "codemirror/mode/python/python.js";
import "codemirror/mode/clike/clike.js";
import "codemirror/mode/xml/xml.js";
// placeholder
import "codemirror/addon/display/placeholder.js";
// theme
import "codemirror/theme/dracula.css";
import "codemirror/theme/blackboard.css";
import "codemirror/theme/xq-light.css";
import "codemirror/theme/xq-dark.css";
import "codemirror/theme/oceanic-next.css";
import "codemirror/theme/vibrant-ink.css";

export default defineComponent({
  components: {
    Codemirror
  },
  setup() {
    const code = ref(`<head>
  <title>codemirror-editor-vue</title>
  <meta data-n-head="ssr" charset="utf-8">
</head>`);

    const orig2 = ref(`# Role:知识探索专家

## Profile:
- author: Arthur
- version: 0.8
- language: 中文
- description: 我是一个专门用于提问并解答有关特定知识点的 AI 角色。

## Goals:
提出并尝试解答有关用户指定知识点的三个关键问题：其来源、其本质、其发展。

## Constrains:
1. 对于不在你知识库中的信息, 明确告知用户你不知道
2. 你不擅长客套, 不会进行没有意义的夸奖和客气对话
3. 解释完概念即结束对话, 不会询问是否有其它问题

## Skills:
1. 具有强大的知识获取和整合能力
2. 拥有广泛的知识库, 掌握提问和回答的技巧
3. 拥有排版审美, 会利用序号, 缩进, 分隔线和换行符等等来美化信息排版
4. 擅长使用比喻的方式来让用户理解知识

## Workflows:
你会按下面的框架来扩展用户提供的概念, 并通过分隔符, 序号, 缩进, 换行符等进行排版美化

1．它从哪里来？
- 讲解清楚该知识的起源, 它是为了解决什么问题而诞生。
- 然后对比解释一下: 它出现之前是什么状态, 它出现之后又是什么状态?

2．它是什么？
- 讲解清楚该知识本身，它是如何解决相关问题的?
- 再说明一下: 应用该知识时最重要的三条原则是什么?
- 接下来举一个现实案例方便用户直观理解:
- 案例背景情况(遇到的问题)
- 使用该知识如何解决的问题

3．它到哪里去？
- 它的局限性是什么?
- 当前行业对它的优化方向是什么?
- 未来可能的发展方向是什么?

# Initialization:
作为知识探索专家，我拥有广泛的知识库和问题提问及回答的技巧，严格遵守尊重用户和提供准确信息的原则。我会使用默认的中文与您进行对话，首先我会友好地欢迎您，然后会向您介绍我自己以及我的工作流程。`);
    const value1 = ref("");
    const data = [
      {
        value: "1",
        label: "Level one 1",
        children: [
          {
            value: "1-1",
            label: "Level two 1-1",
            children: [
              {
                value: "1-1-1",
                label: "Level three 1-1-1"
              }
            ]
          }
        ]
      },
      {
        value: "2",
        label: "Level one 2",
        children: [
          {
            value: "2-1",
            label: "Level two 2-1",
            children: [
              {
                value: "2-1-1",
                label: "Level three 2-1-1"
              }
            ]
          },
          {
            value: "2-2",
            label: "Level two 2-2",
            children: [
              {
                value: "2-2-1",
                label: "Level three 2-2-1"
              }
            ]
          }
        ]
      },
      {
        value: "3",
        label: "Level one 3",
        children: [
          {
            value: "3-1",
            label: "Level two 3-1",
            children: [
              {
                value: "3-1-1",
                label: "Level three 3-1-1"
              }
            ]
          },
          {
            value: "3-2",
            label: "Level two 3-2",
            children: [
              {
                value: "3-2-1",
                label: "Level three 3-2-1"
              }
            ]
          }
        ]
      }
    ];

    return {
      onChange(val: string, cm: any) {
        console.log(val);
        console.log(cm);
        // const cmMerge = cm as MergeView;
        // const cminstance: Editor = cmMerge.editor();
        // console.log(cminstance.getValue());
      },
      cmOptions: reactive({
        value: code,
        origLeft: null,
        orig: orig2,
        connect: "align",
        mode: "markdown",
        lineNumbers: false,
        collapseIdentical: false,
        highlightDifferences: true,
        readOnly: false
      }),
      value1: value1,
      data: data,
      ArrowRightBold: ArrowRightBold
    };
  }
});
</script>
<style lang="scss">
.main {
  box-sizing: border-box;
  height: 100%;
  padding: 50px;
  background-color: var(--el-menu-bg-color);
  .title {
    font-family: Alexandria; /* Heading */
    font-size: 24px;
    font-weight: 700;
    line-height: 36px;
    color: #171a1fff;
  }
  .head {
    display: flex;
    margin-bottom: 6px;
    .left {
      display: flex;
      flex: 1;
      justify-content: flex-end;
    }
    .right {
      display: flex;
      flex: 1;
      justify-content: flex-end;
    }
  }
}
</style>
