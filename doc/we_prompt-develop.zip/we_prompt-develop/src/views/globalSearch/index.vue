<template>
  <div class="content">
    <div class="search-head">
      <div class="form-box">
        <el-form ref="ruleFormRef" :model="modalForm" label-position="top" label-width="100px" style="display: flex">
          <el-form-item label="关键词" prop="keyword" class="form-item">
            <el-input style="width: 481px" v-model="modalForm.keyword" placeholder="关键词" :prefix-icon="Search" />
          </el-form-item>
          <!-- <el-form-item label="搜索范围" prop="searchArea" class="form-item">
            <el-select class="select" v-model="modalForm.searchArea">
              <el-option v-for="(item, index) in searchAreaList" :key="index" :value="item"> {{ item }} </el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="类型" prop="searchType" class="form-item">
            <el-select class="select" v-model="modalForm.searchType">
              <el-option label="用户" :value="1"></el-option>
              <el-option label="提示词" :value="2"></el-option>
              <!-- <el-option v-for="item in searchTypeList" :key="item.value" :value="item.value">
                {{ item.label }}
              </el-option> -->
            </el-select>
          </el-form-item>
        </el-form>
        <!-- <div class="form-btn">
          <el-button @click="resetFn">重置</el-button>
          <el-button color="#7D6CE2" @click="searchFn">搜索</el-button>
        </div> -->
      </div>
      <div class="form-result">
        <span>Result For </span>
        <span class="result-key">" {{ modalForm.keyword }} "</span>
      </div>
    </div>
    <div class="search-content">
      <div class="result-box" v-if="modalForm.searchType == '1'">
        <div class="result-head">
          <div class="left">
            <span>相关用户</span>
            <span>
              (找到<span>{{ resultList.length ? resultList.length : 0 }} </span>条结果)
            </span>
          </div>
          <!-- <div class="right">
            <el-button link>查看全部</el-button>
          </div> -->
        </div>
        <div class="result-content">
          <div class="user-item" v-for="(item, index) in resultList" :key="index">
            <div class="item-avatar">
              <img :src="item.avatar" alt="avatar" />
            </div>
            <div class="item-text">
              <div class="text-head">
                <span class="title"> {{ item.userName }} </span>
                <span class="title-tips">
                  <span style="margin-right: 4px">{{ item.collectNum }}</span>
                  收藏
                </span>
                <span class="title-tips">
                  <span style="margin-right: 4px">{{ item.followNum }}</span>
                  关注
                </span>
              </div>
              <div class="text">
                <span>{{ item.articleDescription }}</span>
              </div>
            </div>
            <div class="item-btn">
              <el-button v-if="item.followStat" :icon="User" color="#626aef"> 已关注 </el-button>
              <el-button v-else :icon="User"> 关注 </el-button>
            </div>
          </div>
        </div>
      </div>
      <div class="result-box" v-else>
        <div class="result-head">
          <div class="left">
            <span>相关内容</span>
            <span>(找到<span>10</span>条结果)</span>
          </div>
          <div class="right">
            <el-button link>查看全部</el-button>
          </div>
        </div>
        <div class="result-content">
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
          <div class="content-item">
            <div class="item-title">
              <span>Arthur_1 提示词作品1</span>
            </div>
            <div class="item-text">
              <span>这是一个能帮你讲清楚复杂问题的老师</span>
            </div>
            <div class="item-footer">
              <div class="footer-left">
                <span>3.4k</span>
                <span><i :class="'iconfont icon-fabulous'"></i> </span>
              </div>
              <div class="footer-right">
                <span>--Arthur_1</span>
                <span class="avatar">
                  <img src="@/assets/images/avatar.gif" alt="avatar" />
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onBeforeMount, onMounted } from "vue";
import { useRoute } from "vue-router";
import { Search, User } from "@element-plus/icons-vue";
import { searchContentList } from "@/api/modules/search";
import { useUserStore } from "@/stores/modules/user";

const userStore = useUserStore();
const route = useRoute();
const searchValue: any = ref("");
const modalForm: any = ref({
  keyword: "",
  searchArea: "",
  searchType: 1
});

// const searchAreaList = ["全局", "我的"];

onBeforeMount(() => {
  searchValue.value = route.query.searchValue;
  modalForm.value.keyword = route.query.searchValue;
});
onMounted(() => {
  console.log(searchValue.value);
  searchFn();
  // 监听 enter 事件（调用登录）
  document.onkeydown = (e: KeyboardEvent) => {
    e = (window.event as KeyboardEvent) || e;
    if (e.code === "Enter" || e.code === "enter" || e.code === "NumpadEnter") {
      if (modalForm.value.keyword && modalForm.value.keyword !== "") {
        searchFn();
      }
    }
  };
});
const resultList: any = ref([]);
const searchFn = () => {
  console.log("搜索");
  searchContentList(userStore.userInfo.userId, searchValue.value, modalForm.value.searchType).then((res: any) => {
    console.log(res);
    if (res.data) {
      resultList.value = res.data;
    }
  });
};
// const resetFn = () => {
//   console.log("重置");
// };
</script>
<style scoped lang="scss">
@import "./index.scss";
</style>
