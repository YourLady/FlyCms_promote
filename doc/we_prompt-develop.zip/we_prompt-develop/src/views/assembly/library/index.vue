<template>
  <div class="container-box">
    <div class="content-head">
      <div class="head">
        <span>我的收藏</span>
      </div>
      <div class="content-sort">
        <div style="padding-bottom: 6px">
          <el-button round :icon="Sort">
            排序:最近更新
            <el-icon class="el-icon--right"><Bottom /> </el-icon>
          </el-button>
        </div>
      </div>
    </div>
    <div class="container">
      <PromptList :list-data="list" :type="'2'" />
    </div>
  </div>
</template>

<script setup lang="ts" name="userInfo">
import { ref, onMounted } from "vue";
import { Sort, Bottom } from "@element-plus/icons-vue";
import PromptList from "@/components/PromptList/index.vue";
import png1 from "@/assets/images/png1.png";
import png2 from "@/assets/images/png2.png";
import png3 from "@/assets/images/png3.png";
import png4 from "@/assets/images/png4.png";
import { getCollectPublishContent } from "@/api/modules/library";
import { useUserStore } from "@/stores/modules/user";
// userStore.userInfo.name
const userStore = useUserStore();

const list: any = ref();
const getList = () => {
  getCollectPublishContent(userStore.userInfo.userId)
    .then((res: any) => {
      console.log(res);
      list.value = res.data;
    })
    .catch(() => {
      list.value = [
        {
          avatar: png1,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "30min"
        },
        {
          avatar: png2,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png3,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        },
        {
          avatar: png4,
          title: "Yummy hamburger",
          content: "hamburgerhamburgerhamburgerhamburgerhamburger",
          time: "1h"
        }
      ];
    });
};
onMounted(() => {
  getList();
});
</script>
<style lang="scss" scoped>
@import "./index.scss";
</style>
