<template>
  <div class="home card">
    <div class="header">
      <div class="header-left">
        <div class="avatar">
          <!-- <img src="@/assets/images/avatar.gif" alt="avatar" /> -->
          <img :src="obj.avatar" alt="avatar" />
        </div>
      </div>
      <div class="header-right">
        <div class="header-title">{{ obj.userName ? obj.userName : obj.nickName }}</div>
        <div class="header-title-control">
          <span>{{ obj.collectCount }}</span>
          <span style="margin-left: 6px">收藏</span>
          <span style="margin-left: 16px">10</span>
          <span style="margin-left: 6px">关注</span>
        </div>
        <div class="header-title-works">
          <span>123</span>
          <span style="margin-left: 6px">作品</span>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="content-head">
        <div class="content-sort">
          <div style="padding-bottom: 6px">
            <el-button round :icon="Sort">
              排序:最近更新
              <el-icon class="el-icon--right"><Bottom /> </el-icon>
            </el-button>
          </div>
        </div>
      </div>
      <div class="content">
        <PromptList :list-data="list" :type="obj.userName ? obj.userName : obj.nickName" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts" name="promptLibrary">
import { ref, onBeforeMount } from "vue";
import { Sort, Bottom } from "@element-plus/icons-vue";
import PromptList from "@/components/PromptList/index.vue";
import png1 from "@/assets/images/png1.png";
import png2 from "@/assets/images/png2.png";
import png3 from "@/assets/images/png3.png";
import png4 from "@/assets/images/png4.png";
import { useRoute } from "vue-router";
import { useUserStore } from "@/stores/modules/user";

const userStore = useUserStore();
const route = useRoute();
const obj: any = ref({});
onBeforeMount(() => {
  console.log(userStore.userInfo.userId);
  console.log(JSON.parse(route.query.row as any));
  obj.value = JSON.parse(route.query.row as any);
});
const list: any = ref([
  {
    avatar: png1,
    title: "Yummy hamburger",
    content: "hamburgerhamburgerhamburgerhamburgerhamburger",
    time: "30min"
  },
  {
    avatar: png2,
    title: "Yummy hamburger",
    content: "hamburgerhamburgerhamburgerhamburgerhamburger",
    time: "1h"
  },
  {
    avatar: png3,
    title: "Yummy hamburger",
    content: "hamburgerhamburgerhamburgerhamburgerhamburger",
    time: "1h"
  },
  {
    avatar: png4,
    title: "Yummy hamburger",
    content: "hamburgerhamburgerhamburgerhamburgerhamburger",
    time: "1h"
  }
]);
</script>

<style scoped lang="scss">
@import "./personage.scss";
</style>
