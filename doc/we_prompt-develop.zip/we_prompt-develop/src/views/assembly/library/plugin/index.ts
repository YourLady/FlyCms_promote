/*
 * @Author: fcli
 * @Date: 2023-09-04 10:34:52
 * @LastEditors: fcli
 * @LastEditTime: 2023-09-21 15:37:44
 * @FilePath: /vue-cubic-bezier/src/plugin/index.ts
 * @Description:
 */
import VueCubicBezier from "./index.vue";

const vueCubicBezier = {
  install(app: any) {
    app.component("VueCubicBezier", VueCubicBezier);
  }
};
export default vueCubicBezier;
