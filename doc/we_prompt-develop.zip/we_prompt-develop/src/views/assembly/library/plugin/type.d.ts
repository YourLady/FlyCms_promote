/*
 * @Author: fcli
 * @Date: 2023-09-04 16:50:16
 * @LastEditors: fcli
 * @LastEditTime: 2023-09-21 14:41:27
 * @FilePath: /vue-cubic-bezier/src/plugin/type.d.ts
 * @Description:
 */

declare module "*.vue" {
  import { defineComponent } from "vue";
  const component: ReturnType<typeof defineComponent>;
  export default component;
}
