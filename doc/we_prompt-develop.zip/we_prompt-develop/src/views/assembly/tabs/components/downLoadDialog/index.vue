<template>
  <el-dialog v-model="dialogVisible" title="" width="730px" draggable>
    <template #header>
      <div>
        <!-- <i :class="'iconfont icon-shouji'" style="margin-right: 10px; color: #1dd75bff"></i> -->
        <el-icon style="margin-right: 10px; color: #1dd75bff"><UploadFilled /></el-icon>
        <span style="font-family: Alexandria; /* Heading */ font-size: 24px; font-weight: 700; line-height: 36px">导出图片</span>
      </div>
    </template>
    <div class="form-box">
      <div class="form-left">
        <div class="tips">
          <span>请选择你喜欢的主题色</span>
        </div>
        <el-radio-group v-model="radio" style="width: 217.01px">
          <el-radio :label="3">
            <span>经典黑</span>
            <span class="label label-color1"> Label </span>
          </el-radio>
          <el-divider />

          <el-radio :label="6">
            <span>雅灰棕</span>
            <span class="label label-color2">Label</span>
          </el-radio>
          <el-divider />

          <el-radio :label="9">
            <span>晨霜灰</span>
            <span class="label label-color3">Label</span>
          </el-radio>
          <el-divider />
          <el-radio :label="12">
            <span>柔珠白</span>
            <span class="label label-color4">Label</span>
          </el-radio>
          <el-divider />
        </el-radio-group>
        <div class="dialog-footer">
          <el-button style="width: 180px; height: 36px" type="primary" @click="downLoadFn">导出</el-button>
        </div>
      </div>
      <div class="form-right">
        <img v-if="radio == 3" src="@/assets/images/downloadimg1.png" alt="" />
        <img v-if="radio == 6" src="@/assets/images/downloadimg2.png" alt="" />
        <img v-if="radio == 9" src="@/assets/images/downloadimg3.png" alt="" />
        <img v-if="radio == 12" src="@/assets/images/downloadimg4.png" alt="" />
      </div>
    </div>
  </el-dialog>

  <div>
    <div class="capture" id="capture">
      <div class="pic-content" :style="{ background: showBgColor }">
        <div class="pic-head">
          <el-divider style="width: 50%" />
          <img v-if="radio == 3 || radio == 6" src="@/assets/images/white-icon.png" alt="avatar" />
          <img v-else src="@/assets/images/black-icon.png" alt="avatar" />
        </div>
        <div class="content">
          <pre class="pre" :style="{ color: showTxtColor }"><code >{{ content }}</code></pre>
          <el-divider style="width: 50%; margin-top: 60px" />
        </div>
      </div>
      <div class="footer">
        <div class="footer-left">
          <div class="img">
            <img src="https://img.js.design/assets/img/654646c6e68d83782579cf5a.png#340c4fe6cca154daabc488dce7ae18f0" alt="" />
          </div>
          <div class="tips">
            <div style="margin-bottom: 10px">「知识探索专家」 Ver.0.8</div>
            <div style="text-indent: 12px">作者：{{ userStore.userInfo.userName }}</div>
          </div>
        </div>
        <div class="footer-right">
          <img src="https://img.js.design/assets/img/654646c6572d7c6d81824f21.png#f14650dc448ba67a17b29d2f00e89092" alt="" />
        </div>
      </div>
      <div class="footer-icon">
        <img src="@/assets/images/black-icon.png" alt="avatar" />
        <div>www.we-prompt.cn</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";
import { useRouter } from "vue-router";
import { useAutoPicture } from "@/hooks/useAutoPicture";
import { useUserStore } from "@/stores/modules/user";

const userStore = useUserStore();
const router = useRouter();
console.log(router);
const dialogVisible = ref(false);
const content: any = ref();
const openDialog = (val: any) => {
  dialogVisible.value = true;
  content.value = val.content;
  console.log(userStore.userInfo.userName);
};
const radio = ref(3);
const downLoadFn = () => {
  // router.push("/autoPicture/index");
  shareImg();
};

defineExpose({ openDialog });
const colorList: any = {
  3: "rgb(23 25 37 / 100%)",
  6: "rgb(120 97 112 / 100%)",
  9: "rgb(237 237 235 / 100%)",
  12: "rgb(254 249 241 / 100%)"
};
const textColor: any = {
  3: "rgb(254 249 241 / 100%)",
  6: "rgb(254 249 241 / 100%)",
  9: "rgb(23 25 37 / 100%)",
  12: "rgb(23 25 37 / 100%)"
};
const showBgColor = computed(() => {
  return colorList[radio.value];
});
const showTxtColor = computed(() => {
  return textColor[radio.value];
});

const show = ref(false);
const currentImg = ref();

const shareImg = async () => {
  const el = document.getElementById(`capture`) as HTMLElement;
  console.log("el:", el);
  el.style.display = "block";
  // const canvasFalse = document.createElement('canvas')
  const width = parseInt(window.getComputedStyle(el).width);
  const height = parseInt(window.getComputedStyle(el).height);
  console.log("width:", width, "height:", height);
  let canvas = await useAutoPicture(`capture`, { width, height });
  el.style.display = "none";
  if (canvas) {
    currentImg.value = canvas;
    show.value = true;
    // canvas为转换后的Canvas对象
    let oImg = new Image();
    oImg = currentImg.value; // 导出图片
    console.log(oImg);
    let oA = document.createElement("a") as any;
    oA.download = "分享内容"; // 设置下载的文件名，默认是'下载'
    oA.href = oImg;
    document.body.appendChild(oA);
    oA.click();
    oA.remove(); // 下载之后把创建的元素删除
  }
};
</script>
<style lang="scss" scoped>
@import "./index.scss";
.capture {
  position: absolute;
  bottom: -100000px;
  box-sizing: border-box;
  display: none;
  width: 1000px;
  padding: 45px;

  // height: 400px;
  background: #ffffff;
  .pic-content {
    padding: 52px;
    background: rgb(254 249 241 / 100%);
    .pic-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      img {
        width: 96px;
        height: 80px;
        margin-left: 10px;
      }
    }
    .content {
      .pre {
        font-size: 24px;
        font-weight: 400;
        line-height: 31.82px;
        color: rgb(255 255 255 / 100%);
        letter-spacing: 0;
        white-space: pre-wrap;
      }
    }
  }
  .footer {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    .footer-left {
      display: flex;
      align-items: center;
      height: 98px;
      .img {
        padding-right: 20px;
        margin-right: 10px;
        border-right: 2px solid;
        img {
          width: 70px;
          height: 70px;
        }
      }
      .tips {
        font-size: 24px;
        font-weight: 600;
        line-height: 31.82px;
        color: rgb(0 0 0 / 100%);
        text-align: left;
        letter-spacing: 0;
        vertical-align: middle;
      }
    }
    .footer-right {
      img {
        width: 98px;
        height: 98px;
      }
    }
  }
  .footer-icon {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 20px;
    font-size: 20px;
    font-weight: 400;
    line-height: 26.52px;
    color: rgb(0 0 0 / 100%);
    letter-spacing: 0;
    img {
      width: 86px;
      height: 81px;
    }
  }
}
</style>
