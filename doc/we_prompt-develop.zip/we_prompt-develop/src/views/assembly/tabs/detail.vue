<template>
  <div class="card content-box">
    <div class="content-head">
      <div class="head-left">
        <div class="title">{{ promoteObj.title }}</div>
        <div v-if="!showEditValue" class="version"><span>Version</span> {{ versionNumber1 }}.{{ versionNumber2 }}</div>
        <div v-if="showEditValue" class="version">
          <span>Version</span>
          <el-input v-model="versionNumber1" class="input-version" />
          <span>.</span>
          <el-input v-model="versionNumber2" class="input-version" />
        </div>
      </div>
      <div class="head-right">
        <el-button v-if="!showEditValue" :icon="Edit" color="#626aef" @click="editFn">编辑</el-button>
        <el-button v-if="!showEditValue" :icon="Promotion">分享</el-button>
        <!-- <el-button v-if="!showEditValue" :icon="ChatDotRound" @click="openDrawer">评论</el-button> -->
      </div>
    </div>
    <div class="content">
      <div v-if="showEditValue" class="edit-content">
        <div class="edit-button">
          <div style="flex: 2">
            <span style="font-family: ABeeZee; /* Body */ font-size: 14px; font-weight: 400; line-height: 22px; color: #9095a1ff">
              3764 tokens
            </span>
            <!-- <span class="line"></span> -->
            <!-- <el-select class="select" v-model="themeVal" @change="selectTheme">
              <el-option v-for="(item, index) in themeList" :key="index" :value="item"> {{ item }} </el-option>
            </el-select> -->
            <!-- <span class="line"></span> -->
          </div>
          <div style="display: flex; justify-content: space-around">
            <div style="margin-right: 6px">
              <el-select style="" class="select" v-model="language">
                <template #prefix>
                  <SvgIcon name="Tree1" :icon-style="{ width: '12px', height: '12px', verticalAlign: 'bottom' }" />
                </template>
                <el-option v-for="(item, index) in languageList" :key="index" :value="item.value"> {{ item.label }} </el-option>
              </el-select>
            </div>
            <div style="margin-right: 6px">
              <el-button @click="setZoomIn">
                <i :class="'iconfont icon-zoom-in'"></i>
              </el-button>
              <el-button @click="setZoomOut"> <i :class="'iconfont icon-zoom-out'"></i></el-button>
            </div>
            <div>
              <!-- @click="copyValue" -->

              <el-button @click="download" :icon="Download">导出</el-button>
              <!-- <el-button class="tag-read" v-copy="value" :icon="CopyDocument">保存</el-button> -->
              <el-button v-if="showEditValue" color="#626aef" @click="saveFn">
                <i :class="'iconfont icon-save mr10'"></i>
                保存
              </el-button>
            </div>
            <!-- <el-button :icon="Delete" @click="getValue"></el-button> -->
          </div>
        </div>

        <div class="edit-monaco">
          <mirrorTextArea v-model:modelValue="value" :font-size="fontSize" :theme="themeVal" :mode="language" />
        </div>
      </div>
      <div v-else class="view">
        <pre><code>{{ content }}</code></pre>
      </div>
    </div>
    <div style="height: 100px"></div>
    <!-- downLoadDialog -->
    <downLoadDialog ref="downLoadRef" />
  </div>
</template>

<script setup lang="ts" name="tabsDetail">
import { useRoute, useRouter } from "vue-router";
import { useTabsStore } from "@/stores/modules/tabs";
// import { useHomeStore } from "@/stores/modules/home";
import SvgIcon from "@/components/SvgIcon/index.vue";
// import { ElMessage } from "element-plus";
import { ref, onBeforeMount } from "vue";
// import * as monaco from "monaco-editor";
// import Clipboard from "clipboard";
// import monacoEditor from "@/components/MonacoEditor/index.vue";
import mirrorTextArea from "@/components/MirrorTextArea/mirrorTextArea.vue";
import downLoadDialog from "./components/downLoadDialog/index.vue";
import { Promotion, Edit, Download } from "@element-plus/icons-vue";
import { findArticleById, addSaveArticle } from "@/api/modules/library";
import { useUserStore } from "@/stores/modules/user";

const userStore = useUserStore();

const content = ref(
  "## 学习新的技术)学习新的技术\r\n\r\n\
学习新技术的时候，你可能会根据官方文档或博客来构建技术框架,\r\n\r\n\
在构建框架时因为版本冲突、配置遗漏、对技术理解不到位等问题折腾到大半夜.\r\n\r\n\
此时此刻，也许在CodeRd中有一套现成的可供参考。"
);

const route = useRoute();
const router = useRouter();
console.log(router);
const tabStore = useTabsStore();
// const homeStore = useHomeStore();
const downLoadRef = ref();
const promoteObj = ref();
tabStore.setTabsTitle(`No.${route.params.id} - ${route.meta.title}`);

onBeforeMount(() => {
  const row = JSON.parse(route.query.row as any);
  console.log(row.promoteid);
  promoteObj.value = row;
  if (route.query.type == "edit") {
    showEditValue.value = true;
  } else {
    showEditValue.value = false;
    getDataByPromoteId(row.id);
  }
});
//  通过id 获取详情
const getDataByPromoteId = (id: any) => {
  findArticleById(id).then((res: any) => {
    console.log("通过id 获取详情", res);
  });
};
const value = ref("let a = 234\r\n\r\n\r\n\r\n\r\n\r\ndasdasd\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\ndasdasd");
const language = ref("Markdown");
const themeVal = ref("base16-light");
// const selectTheme = (val: string) => {
//   homeStore.setTheme(val);
//   themeVal.value = val;
// };

const versionNumber1 = ref(1);
const versionNumber2 = ref(0);

let languageList = ref([
  { label: "JAVA", value: "text/x-java" },
  { label: "PYTHON", value: "python" },
  { label: "HTML", value: "text/html" },
  { label: "XML", value: "text/html" },
  { label: "YAML", value: "yaml" },
  { label: "Markdown", value: "markdown" }
]);
// let themeList = ref(["base16-light", "blackboard", "base16-dark"]);
const fontSize = ref("14px");
const level = ref(14);

const showEditValue = ref(false);
const editFn = () => {
  console.log(content.value);
  value.value = content.value;
  showEditValue.value = true;
};
const saveFn = () => {
  content.value = value.value;
  console.log(content.value);
  const param = {
    userId: userStore.userInfo.userId,
    title: "测试promote",
    promoteid: promoteObj.value.promoteid,
    content: content.value,
    color: "00x8",
    contentstyle: "consoler",
    promote_version: `${versionNumber1.value}.${versionNumber2.value}`
  };
  console.log("param", param);
  addSaveArticle(param).then((res: any) => {
    console.log(res);
  });
  showEditValue.value = false;
};
const setZoomIn = () => {
  if (level.value != 14) {
    fontSize.value = (level.value -= 1) + "px";
  }
};
const setZoomOut = () => {
  fontSize.value = (level.value += 1) + "px";
};

const download = () => {
  // /autoPicture/index
  // router.push("/autoPicture/index");
  const params = {
    content: value.value,
    title: ""
  };
  downLoadRef.value?.openDialog(params);
};
</script>
<style scoped lang="scss">
.content-box {
  align-items: flex-start;
  width: 100%;
  height: 100%;
  padding: 50px;
  .content-head {
    display: flex;
    align-items: flex-end;
    justify-content: space-around;
    width: 100%;
    .head-left {
      display: flex;
      justify-content: space-around;
      .title {
        width: 341px;
        font-family: Alexandria;
        font-size: 32px;
        font-weight: 700;
        line-height: 48px;
        color: #171a1fff;
      }
      .version {
        font-family: Alexandria;
        font-size: 20px;
        font-weight: 600;
        line-height: 48px;
        color: #565d6dff;
        .input-version {
          width: 40px;
          margin: 0 10px;
        }
      }
    }
    .head-right {
      display: flex;
      flex: 1;
      justify-content: flex-end;
    }
  }
  .content {
    box-sizing: border-box;
    display: flex;
    width: 100%;

    // height: 100%;
    margin-top: 80px;
    .view {
      width: 100%;
      min-height: 400px;

      // height: 100%;
      padding: 0 10px;
      border: 1px solid var(--el-border-color);
    }
    .edit-content {
      width: 100%;
      height: 100%;
      .edit-monaco {
        width: 100%;
        height: 500px;
        padding-top: 30px;
        border-top: 1px solid var(--el-border-color);
      }
      .edit-button {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        .select {
          width: 178px;
          height: 36px;
        }
        .line {
          display: inline-block;
          width: 46px;
          height: 0;
          border-color: #dee1e6ff; /* neutral-300 */
          border-style: solid;
          border-width: 1px;
          transform: rotate(90deg);
        }
      }
    }
  }
}
</style>
