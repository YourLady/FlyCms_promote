<template>
  <div class="home card">
    <el-tabs v-model="activeName" type="card" class="demo-tabs" @tab-click="handleClick">
      <el-tab-pane v-for="(item, index) in tabsList" :key="index" :label="item.label" :name="item.name">
        <Stroll v-if="item.name === 'stroll'" :list-data="strollList" />
        <Follow v-if="item.name === 'follow'" :list-data="followList" :follow-user-list="followUserList" />
        <Mine v-if="item.name === 'mine'" :list-data="mineList" />
      </el-tab-pane>
    </el-tabs>
    <div class="custom-btn">
      <el-button :icon="MagicStick" @click="editDynamicFn">show 提示词</el-button>
    </div>
  </div>
</template>

<script setup lang="ts" name="home">
import { ref, onMounted, provide } from "vue";
import type { TabsPaneContext } from "element-plus";
import Stroll from "./componenets/Stroll/index.vue";
import Follow from "./componenets/Follow/index.vue";
import Mine from "./componenets/Mine/index.vue";
import { MagicStick } from "@element-plus/icons-vue";
import { useRouter } from "vue-router";
import { useUserStore } from "@/stores/modules/user";
import { getRecommendList, getMyContentList, getFollowContentList, getFollowUsersList } from "@/api/modules/home";

const userStore = useUserStore();
const router = useRouter();
const activeName = ref("stroll");
const tabsList = [
  {
    label: "逛逛",
    name: "stroll"
  },
  {
    label: "关注",
    name: "follow"
  },
  {
    label: "我的",
    name: "mine"
  }
];
const strollList = ref([]);
const followList = ref([]);
const mineList = ref([]);
const followUserList = ref([]);

const handleClick = (tab: TabsPaneContext) => {
  console.log(tab.paneName);
  if (tab.paneName == "stroll") {
    getStrollList();
  }
  if (tab.paneName == "mine") {
    getMineList();
  }
  if (tab.paneName == "follow") {
    getFollowList();
    getFollowUserList();
  }
};
const editDynamicFn = () => {
  router.push("/editDynamic/index");
};
const getStrollList = () => {
  getRecommendList(userStore.userInfo.userId).then((res: any) => {
    console.log(res);
    if (res.code == 0) {
      strollList.value = res.data;
    }
  });
};
const getMineList = () => {
  getMyContentList(userStore.userInfo.userId).then((res: any) => {
    console.log(res);
    if (res.code == 0) {
      mineList.value = res.data;
    }
  });
};
const getFollowList = () => {
  getFollowContentList(userStore.userInfo.userId).then((res: any) => {
    console.log(res);
    if (res.code == 0) {
      followList.value = res.data;
    }
  });
};
// 获取关注列表
const getFollowUserList = () => {
  getFollowUsersList(userStore.userInfo.userId).then((res: any) => {
    if (res.code == 0) {
      res.data.forEach((element: any) => {
        element.showVisible = false;
      });
      followUserList.value = res.data;
    }
  });
};
onMounted(() => {
  getStrollList();
  // getMineList();
  // getFollowList();
});
// 注入刷新页面方法
const refreshStrollList = () => {
  getStrollList();
};
const refreshMineList = () => {
  getMineList();
};

const refreshFollowList = () => {
  getFollowList();
  getFollowUserList();
};
provide("refreshStroll", refreshStrollList);
provide("refreshMine", refreshMineList);
provide("refreshFollow", refreshFollowList);
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
