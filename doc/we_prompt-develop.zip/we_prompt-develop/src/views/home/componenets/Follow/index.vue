<template>
  <div class="container">
    <div>
      <div v-for="(item, index) in listData" :key="index">
        <ShowPromptCard :card-obj="item" :get-list="getList" :is-show-follow="true" />
      </div>
    </div>
    <div v-if="followUserList.length > 0">
      <FollowList :follow-user-list="followUserList" />
    </div>
  </div>
  <div class="message-empty" v-if="listData && listData.length == 0">
    <img src="@/assets/images/notData.png" alt="notData" />
    <div>暂无消息</div>
  </div>
</template>
<script setup lang="ts" name="stroll">
// import { getFollowContentList } from "@/api/modules/home";
import { inject } from "vue";
import ShowPromptCard from "@/components/ShowPromptCard/index.vue";
import FollowList from "./components/FollowList/index.vue";
// import { useUserStore } from "@/stores/modules/user";
// const userStore = useUserStore();

// onMounted(() => {
//   getList();
// });
// const followContentList = ref([]);
// const getList = () => {
//   getFollowContentList(userStore.userInfo.userId).then((res: any) => {
//     console.log(res);
//     if (res.code == 0) {
//       followContentList.value = res.data;
//     }
//   });
// };
type Props = {
  listData: Home.CardObjProps[];
  followUserList: any[];
};
defineProps<Props>();
const getList = () => {
  refreshCurrentPage();
};
const refreshCurrentPage: Function = inject("refreshFollow") as Function;
</script>
<style scoped lang="scss">
@import "./index.scss";
</style>
