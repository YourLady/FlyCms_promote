<template>
  <div>
    <el-card class="card-box">
      <template #header>
        <div class="card-header">
          <span>关注</span>
          <span class="round">{{ followUserList.length }}</span>
        </div>
      </template>
      <div v-for="(o, index) in followUserList" :key="index" class="text item">
        <div class="avatar" @click="toPersonage(o)">
          <img :src="o.avatar" alt="avatar" />
          <!-- @/assets/images/avatar.gif -->
        </div>
        <div>{{ o.nickName }}</div>
        <div style="margin-left: auto" class="item-tips">
          <el-popover placement="right-start" :width="80" trigger="click">
            <template #reference>
              <el-icon :size="12" style="transform: rotate(90deg)">
                <MoreFilled />
              </el-icon>
            </template>
            <div class="cancel" @click.stop="cancelSelectParam(o)">
              <el-icon>
                <Unlock />
              </el-icon>
              <span>取消关注</span>
            </div>
          </el-popover>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script setup lang="ts" name="stroll">
import { onMounted, inject } from "vue";

import { useRouter } from "vue-router";
import { setCancelFollowUsers } from "@/api/modules/home";
import { ElMessage } from "element-plus";
// const route = useRoute();
import { useUserStore } from "@/stores/modules/user";
// import { ClickOutside as vClickOutside } from "element-plus";

const userStore = useUserStore();
const router = useRouter();
type Props = {
  followUserList: any[];
};
defineProps<Props>();
onMounted(() => {
  // getList();
});

// const followUsersList = ref<any>([]);
// // 获取关注列表
// const getList = () => {
//   getFollowUsersList(userStore.userInfo.userId).then((res: any) => {
//     if (res.code == 0) {
//       res.data.forEach((element: any) => {
//         element.showVisible = false;
//       });
//       followUsersList.value = res.data;
//     }
//   });
// };
// const selectParam = (item: any) => {
//   console.log("data", item);
//   item.showVisible = true;
// };
// 取消关注
const cancelSelectParam = (row: any) => {
  console.log("取消关注");
  let params = {
    userId: userStore.userInfo.userId,
    followUserId: row.userId
  };
  setCancelFollowUsers(params)
    .then((res: any) => {
      console.log(res);
      if (res.code == 0) {
        ElMessage.success(res.message);
      }
      refreshCurrentPage();
    })
    .catch(() => {
      refreshCurrentPage();
    });
  row.showVisible = false;
};
const toPersonage = (row: any) => {
  console.log(row);
  let obj = JSON.stringify(row);
  router.push({
    path: `/assembly/library/personage/`,
    query: { row: obj }
  });
};
const refreshCurrentPage: Function = inject("refreshFollow") as Function;
</script>
<style scoped lang="scss">
@import "./index.scss";
</style>
