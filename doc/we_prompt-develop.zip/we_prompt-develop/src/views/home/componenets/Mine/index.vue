<template>
  <div v-for="(item, index) in listData" :key="index">
    <ShowPromptCard :card-obj="item" :get-list="getList" :is-show-follow="false" />
  </div>
  <div class="message-empty" v-if="listData && listData.length == 0">
    <img src="@/assets/images/notData.png" alt="notData" />
    <div>暂无消息</div>
  </div>
</template>
<script setup lang="ts" name="stroll">
import { inject } from "vue";
import ShowPromptCard from "@/components/ShowPromptCard/index.vue";

type Props = {
  listData: Home.CardObjProps[];
};
defineProps<Props>();
const getList = () => {
  refreshCurrentPage();
};
const refreshCurrentPage: Function = inject("refreshMine") as Function;
</script>
<style lang="scss">
.message-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 260px;
  line-height: 45px;
}
</style>
