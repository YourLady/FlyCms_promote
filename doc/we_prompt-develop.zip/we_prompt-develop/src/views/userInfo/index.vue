<template>
  <div class="content-box">
    <div class="content-left">
      <div class="card info">
        <div class="avatar">
          <!-- <img src="https://cs.prompty.top/upload/avatar/20231111/920729134693625856/avatar.jpg" alt="avatar" /> -->
          <img :src="userStore.userInfo.avatar" alt="avatar" />
          <span class="edit-avatar">
            <UploadImg v-model:image-url="avatar2" :type="'1'" :drag="false">
              <template #empty>
                <el-icon :size="20" style="margin-top: 6px; color: #ffffff">
                  <Edit />
                </el-icon>
              </template>
            </UploadImg>
          </span>
        </div>
        <div class="title">{{ userStore.userInfo.userName }}</div>
        <div class="remake">
          {{ userStore.userInfo.description }}
        </div>
      </div>
      <div class="card bind">
        <div class="bind-wx" @click="openDialog('infoRef')">
          <div>
            <i :class="'iconfont icon-weixin'" style="color: #1dd75bff"></i>
            <span class="wx-text" style=""> 微信账号 </span>
          </div>
          <div class="flx-align-center">
            <el-icon style="color: red"><Warning /></el-icon>
            <span class="un-bind">未绑定</span>
          </div>
        </div>
        <div class="bind-wx" @click="openDialog('passwordRef')">
          <div>
            <i :class="'iconfont icon-shouji'" style="color: #1dd75bff"></i>
            <span class="wx-text">手机账号</span>
          </div>
          <div class="flx-align-center">
            <el-icon style="color: #1dd75bff"><CircleCheck /></el-icon>
            <span class="bound">已绑定</span>
          </div>
        </div>
      </div>
    </div>
    <div class="content-right">
      <div class="title">
        <span class="text">我的信息</span>
        <span @click="editFn" v-show="isDisabled">
          <el-icon><Edit /></el-icon>
        </span>
      </div>
      <div class="form-box">
        <el-form ref="ruleFormRef" :model="modalForm" :disabled="isDisabled" label-position="top" label-width="100px">
          <el-form-item label="用户名" prop="worksName">
            <el-input v-model="modalForm.worksName" placeholder="用户名" />
          </el-form-item>
          <el-form-item label="我的 Prompt Slogan" prop="description">
            <el-input v-model="modalForm.description" type="textarea" placeholder="请输入你的Prompt Slogan" clearable />
          </el-form-item>
        </el-form>
        <div class="form-btn" v-show="!isDisabled">
          <el-button @click="cancel">取消</el-button>
          <el-button color="#7D6CE2" @click="save">保存</el-button>
        </div>
      </div>
    </div>
    <!-- infoDialog -->
    <BindWxDialog ref="infoRef" />
    <!-- passwordDialog -->
    <BindPhoneDialog ref="passwordRef" />
  </div>
</template>

<script setup lang="ts" name="userInfo">
import { ref, watch, onMounted } from "vue";
// import { HOME_URL } from "@/config";
import { useRoute, useRouter } from "vue-router";
import { useTabsStore } from "@/stores/modules/tabs";
import { useGlobalStore } from "@/stores/modules/global";
import { useKeepAliveStore } from "@/stores/modules/keepAlive";
import BindWxDialog from "./components/BindWxDialog.vue";
import BindPhoneDialog from "./components/BindPhoneDialog.vue";
import UploadImg from "@/components/Upload/Img.vue";
// import { getUserInfo } from "@/api/modules/user";
import { Edit } from "@element-plus/icons-vue";
import { useUserStore } from "@/stores/modules/user";
import { updateUserInfo } from "@/api/modules/user";
// import { ElMessage } from "element-plus";

const route = useRoute();
const router = useRouter();
const tabStore = useTabsStore();
const globalStore = useGlobalStore();
const keepAliveStore = useKeepAliveStore();
const userStore = useUserStore();

console.log(route, router, tabStore, globalStore, keepAliveStore);
const modalForm = ref({
  worksName: userStore.userInfo.userName,
  description: ""
});
const isDisabled = ref(true);

const editFn = () => {
  isDisabled.value = false;
};
const cancel = () => {
  isDisabled.value = true;
};
const save = () => {
  isDisabled.value = true;
  const params = {
    ...userStore.userInfo
  };
  userStore.setUserInfo({
    ...userStore.userInfo,
    userName: modalForm.value.worksName,
    description: modalForm.value.description
  });
  updateUserInfo(params).then((res: any) => {
    console.log(res);
  });
};
// 打开修改密码和个人信息弹窗
const infoRef = ref();
const passwordRef = ref();
const avatar2 = ref("");
const openDialog = (ref: string) => {
  if (ref == "infoRef") infoRef.value?.openDialog();
  if (ref == "passwordRef") {
    passwordRef.value?.openDialog();
  }
};
watch(
  () => avatar2.value,
  (newValue: any) => {
    console.log("newValue", newValue);
    if (newValue) {
      userStore.setUserInfo({
        ...userStore.userInfo,
        avatar: newValue
      });
    }
    avatar2.value = "";
  },
  { deep: true }
);
// const getUserInfoFn = async () => {
//   const { data } = await getUserInfo();
//   console.log(data);
// };

onMounted(() => {
  // getUserInfoFn();
});
</script>
<style lang="scss" scoped>
@import "./index.scss";
</style>
