<template>
  <el-dialog v-model="dialogVisible" title="" width="500px" draggable>
    <template #header>
      <div>
        <i :class="'iconfont icon-shouji'" style="margin-right: 10px; color: #1dd75bff"></i>
        <span>绑定手机号</span>
      </div>
    </template>
    <div class="form-box">
      <el-form
        ref="ruleFormRef"
        :model="modalForm"
        :autocomplete="'off'"
        :size="'large'"
        label-position="top"
        label-width="100px"
      >
        <el-form-item label="手机号" prop="phone">
          <el-input
            v-model="modalForm.phone"
            :autocomplete="'phone'"
            :readonly="readonlyInput"
            @focus="cancelReadOnly()"
            placeholder="手机号"
          />
        </el-form-item>
        <el-form-item label="验证码" prop="checkCode">
          <el-input v-model="modalForm.checkCode" placeholder="验证码">
            <template #append>
              <div>
                <el-button type="primary" v-if="showCode" class="code_type" @click.stop="sendVerificationCode">
                  发送验证码
                </el-button>
                <el-button type="primary" class="code_type" v-if="!showCode" disabled> {{ count }}秒后重发 </el-button>
              </div>
            </template>
          </el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="modalForm.password"
            :autocomplete="'off'"
            type="password"
            placeholder="密码需要包括至少8位字母和数字"
          >
            <template #prefix>
              <el-icon class="el-input__icon">
                <lock />
              </el-icon>
            </template>
          </el-input>
        </el-form-item>
      </el-form>
    </div>
    <template #footer>
      <span class="dialog-footer">
        <!-- <el-button @click="dialogVisible = false">取消</el-button> -->
        <el-button type="primary" :loading="loading" @click="bind(ruleFormRef)">确定修改</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref } from "vue";
import { getMobileCode, setMobileUpdate } from "@/api/modules/login"; // loginApi,
import { ElNotification } from "element-plus";
import type { ElForm } from "element-plus";
import { useUserStore } from "@/stores/modules/user";
import { getTimeState } from "@/utils";

const userStore = useUserStore();
const dialogVisible = ref(false);
const openDialog = () => {
  dialogVisible.value = true;
  // modalForm.value.phone = userStore.userInfo.userMobile;
  modalForm.value.phone = "";
  modalForm.value.password = "";
};
const modalForm = ref({
  phone: "",
  checkCode: "",
  password: ""
});

//验证码 倒计时
const showCode = ref(true);
const count = ref();
const timer = ref();
const sendVerificationCode = () => {
  let TIME_COUNT = 60;
  if (!timer.value) {
    count.value = TIME_COUNT;
    showCode.value = false;
    timer.value = setInterval(() => {
      if (count.value > 0 && count.value <= TIME_COUNT) {
        count.value--;
      } else {
        showCode.value = true;
        clearInterval(timer.value);
        timer.value = null;
      }
    }, 1000);
    getCode();
  }
};
const getCode = async () => {
  // /ucenter/safemobilecode
  const { data } = await getMobileCode(modalForm.value.phone, userStore.userInfo.userId);
  console.log(data);
};

type FormInstance = InstanceType<typeof ElForm>;
const ruleFormRef = ref<FormInstance>();
const loading = ref(false);
const bind = (formEl: FormInstance | undefined) => {
  if (!formEl) return;
  formEl.validate(async valid => {
    if (!valid) return;
    loading.value = true;
    try {
      // 1.执行注册接口
      const param = {
        mobile: modalForm.value.phone,
        password: modalForm.value.password,
        code: modalForm.value.checkCode,
        userid: userStore.userInfo.userId
      };
      console.log(param);
      // { ...loginForm, password: md5(loginForm.password) }
      const { data } = await setMobileUpdate(param);
      console.log(data);

      // 4.跳转到登录

      ElNotification({
        title: getTimeState(),
        message: "绑定手机号码成功",
        type: "success",
        duration: 3000
      });
    } finally {
      loading.value = false;
    }
  });
};
const readonlyInput = ref(true);

const cancelReadOnly = () => {
  readonlyInput.value = false;
};

defineExpose({ openDialog });
</script>
<style lang="scss" scoped>
.form-box {
  padding: 0 50px;
}
.dialog-footer {
  display: flex;
  justify-content: center;
}
</style>
