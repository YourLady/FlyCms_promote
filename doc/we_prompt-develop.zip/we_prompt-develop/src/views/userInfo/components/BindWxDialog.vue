<template>
  <el-dialog v-model="dialogVisible" title="" width="500px" draggable>
    <template #header>
      <div>
        <i :class="'iconfont icon-weixin'" style="margin-right: 10px; color: #1dd75bff"></i>
        <span>绑定微信账号</span>
      </div>
    </template>
    <div class="wx-img">
      <i :class="'iconfont icon-erweima'" style="font-size: 280px"></i>
      <span>使用微信扫码</span>
    </div>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref } from "vue";

const dialogVisible = ref(false);
const openDialog = () => {
  dialogVisible.value = true;
};

defineExpose({ openDialog });
</script>
<style lang="scss" scoped>
.wx-img {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
</style>
