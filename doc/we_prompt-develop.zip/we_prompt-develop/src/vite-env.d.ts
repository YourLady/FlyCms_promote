/// <reference types="vite/client" />
declare module "*.js";
